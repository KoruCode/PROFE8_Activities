Tutor Booking Services

A responsive Flutter application that connects students with expert tutors across multiple subjects including Mathematics, Physics, Chemistry, Biology, and English. The app features a comprehensive tutor browsing system with real-time search and filtering capabilities, allowing students to easily find and book tutoring sessions with qualified instructors. Students can chat with tutors through an integrated messaging system to ask questions, coordinate sessions, and receive learning support. The application includes a complete profile management system where users can edit their personal information, manage account settings, view booking history, and track their learning progress.

Built with a clean architecture pattern, the app is fully responsive and adapts seamlessly across mobile phones (single column layout with drawer navigation), tablets (two-column layout with enhanced spacing), and desktop computers (multi-column layout with permanent sidebar navigation).

The project structure follows Flutter best practices with organized folders for models, services, views, and reusable widgets — making it easy to maintain and extend with future features like enhanced chat, payment integration, calendar synchronization, and analytics.

## 🌳 Widget Tree Diagram & Architecture

### Complete Widget Hierarchy

```plaintext
MaterialApp (Root)
└── MainNavigation (StatefulWidget)
    └── Scaffold
        ├── IndexedStack (Preserves state across tabs)
        │   ├── [Index 0] HomePage (StatefulWidget)
        │   │   └── Scaffold
        │   │       ├── AppBar
        │   │       │   ├── Text (title)
        │   │       │   └── Container (booking count badge)
        │   │       ├── Drawer (Mobile/Tablet only)
        │   │       │   ├── Container (gradient header)
        │   │       │   │   ├── CircleAvatar (app icon)
        │   │       │   │   ├── Text (app name)
        │   │       │   │   └── Row (quick stats)
        │   │       │   └── ListView (menu items → ListTile widgets)
        │   │       └── Body: Row (Desktop) / Column (Mobile)
        │   │           ├── [Desktop] Sidebar Container (300px)
        │   │           └── Expanded (Main Content)
        │   │               ├── Container (gradient background)
        │   │               ├── Header Section
        │   │               │   ├── Text (title)
        │   │               │   ├── Text (subtitle)
        │   │               │   └── CustomButton (search)
        │   │               ├── Subject Filter Bar
        │   │               │   └── ListView.builder (FilterChips)
        │   │               └── MasonryGridView (Third-party package)
        │   │                   └── TutorCard widgets
        │   │                       ├── Container (card shell)
        │   │                       ├── Stack (avatar + online indicator)
        │   │                       └── Column (tutor info)
        │   │                           ├── Text (name)
        │   │                           ├── Container (subject badge)
        │   │                           ├── Row (rating stars)
        │   │                           └── Text (hourly rate)
        │   │                       └── ElevatedButton (book now)
        │   │
        │   ├── [Index 1] BookingPage (StatefulWidget)
        │   │   └── ListView.builder (BookingCard widgets)
        │   │
        │   ├── [Index 2] MessagesPage (StatefulWidget)
        │   │   └── ListView.builder (ConversationTile widgets)
        │   │
        │   └── [Index 3] ProfilePage (StatefulWidget)
        │       └── Form with TextFormField widgets
        │
        └── BottomNavigationBar
            └── BottomNavigationBarItem widgets (4 tabs)

[Overlays] Dialogs, SnackBars, etc.
Theme & Material Design Configuration


Parent-Child Relationships Explained

Root Level (MaterialApp)

Parent: None (root widget)

Child: MainNavigation

Purpose: Provides Material Design theme, routing, and app-wide configuration

Navigation Level (MainNavigation)

Parent: MaterialApp

Children: Scaffold → IndexedStack + BottomNavigationBar

Purpose: Manages bottom tab navigation and preserves state across tabs using IndexedStack

Page Level (HomePage, BookingPage, MessagesPage, ProfilePage)

Parent: IndexedStack (within MainNavigation)

Children: Scaffold → AppBar + Drawer + Body

Purpose: Individual screens with their own app bars, navigation, and content areas

Layout Level (Desktop Row / Mobile Column)

Parent: Scaffold body

Children: [Desktop] Sidebar + Expanded content / [Mobile] Single column

Purpose: Responsive layout adapting to screen size

Content Level (MasonryGridView + TutorCard)

Parent: Expanded content area

Children: TutorCard widgets in staggered grid

Purpose: Displays tutors in visually appealing way

Component Level (TutorCard)

Parent: MasonryGridView

Children: Container → Stack (avatar + indicator) + Column (info) + Button

Purpose: Reusable dynamic-height tutor card

📦 Third-Party Package Integration

This app uses flutter_staggered_grid_view for Pinterest-style layouts.

MasonryGridView: Staggered grids

Dynamic Heights: Visually interesting cards

Responsive Design: Adapts to mobile/tablet/desktop

Performance: Optimized scrolling

🚀 Getting Started

Install Flutter → flutter.dev

Clone the project:

git clone <your-repo>
cd tutor_booking_app


Get dependencies:

flutter pub get


Run the app:

flutter run

📁 Project Structure

lib/
├── main.dart                # App entry point
├── models/
│   └── tutor.dart           # Tutor data model
├── services/
│   ├── tutor_service.dart   # Tutor data management
│   └── booking_service.dart # Booking management
├── views/
│   ├── main_navigation.dart # Bottom tab navigation
│   ├── home_page.dart       # Browse tutors
│   ├── booking_page.dart    # Manage bookings
│   ├── messages_page.dart   # Chat with tutors
│   └── profile_page.dart    # Edit profile
└── widgets/
    ├── tutor_card.dart      # Dynamic height tutor cards
    ├── custom_button.dart   # Reusable buttons
    └── booking_form.dart    # Booking form

✨ Features

Browse Tutors with filters and grid view

Book Sessions with scheduling

Chat with tutors in real-time

Manage Profile with booking history

Responsive design across mobile, tablet, and desktop