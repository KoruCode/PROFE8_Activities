package com.example.tutorappointmentapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
