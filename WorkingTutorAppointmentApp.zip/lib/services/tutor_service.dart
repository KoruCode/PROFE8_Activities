import '../models/tutor.dart';

/// Service class for managing tutor data and operations
/// Enhanced with available time slots for booking functionality
class TutorService {
  static List<Tutor> getTutors() {
    return [
      Tutor(
        id: '1',
        name: 'Dr. Maria Rodriguez',
        subject: 'Mathematics',
        rating: 4.9,
        hourlyRate: 45,
        isAvailable: true,
        avatarUrl:
            'https://images.unsplash.com/photo-1494790108755-2616c169174f?w=150&h=150&fit=crop&crop=face',
        availableSlots: [
          '09:00 AM',
          '10:00 AM',
          '02:00 PM',
          '03:00 PM',
          '04:00 PM'
        ],
      ),
      Tutor(
        id: '2',
        name: 'Prof. James Wilson',
        subject: 'Physics',
        rating: 4.7,
        hourlyRate: 50,
        isAvailable: false,
        avatarUrl:
            'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
        availableSlots: ['11:00 AM', '01:00 PM', '05:00 PM'],
      ),
      Tutor(
        id: '3',
        name: 'Ms. Lisa Chen',
        subject: 'Chemistry',
        rating: 4.8,
        hourlyRate: 42,
        isAvailable: true,
        avatarUrl:
            'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop&crop=face',
        availableSlots: [
          '08:00 AM',
          '09:00 AM',
          '01:00 PM',
          '02:00 PM',
          '03:00 PM',
          '06:00 PM'
        ],
      ),
      Tutor(
        id: '4',
        name: 'Dr. Ahmed Hassan',
        subject: 'Biology',
        rating: 4.6,
        hourlyRate: 38,
        isAvailable: true,
        avatarUrl:
            'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
        availableSlots: [
          '10:00 AM',
          '11:00 AM',
          '12:00 PM',
          '04:00 PM',
          '05:00 PM'
        ],
      ),
      Tutor(
        id: '5',
        name: 'Prof. Sarah Thompson',
        subject: 'English',
        rating: 4.9,
        hourlyRate: 40,
        isAvailable: false,
        avatarUrl:
            'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
        availableSlots: ['09:00 AM', '10:00 AM', '02:00 PM'],
      ),
      Tutor(
        id: '6',
        name: 'Dr. Michael Brown',
        subject: 'Mathematics',
        rating: 4.5,
        hourlyRate: 46,
        isAvailable: true,
        avatarUrl:
            'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop&crop=face',
        availableSlots: ['08:00 AM', '01:00 PM', '03:00 PM', '04:00 PM'],
      ),
      Tutor(
        id: '7',
        name: 'Ms. Emily Davis',
        subject: 'Chemistry',
        rating: 4.8,
        hourlyRate: 44,
        isAvailable: true,
        avatarUrl:
            'https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?w=150&h=150&fit=crop&crop=face',
        availableSlots: [
          '09:00 AM',
          '11:00 AM',
          '12:00 PM',
          '02:00 PM',
          '05:00 PM'
        ],
      ),
      Tutor(
        id: '8',
        name: 'Prof. David Kim',
        subject: 'Physics',
        rating: 4.7,
        hourlyRate: 48,
        isAvailable: false,
        avatarUrl:
            'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop&crop=face',
        availableSlots: ['10:00 AM', '01:00 PM', '04:00 PM'],
      ),
      Tutor(
        id: '9',
        name: 'Dr. Rachel Green',
        subject: 'Biology',
        rating: 4.9,
        hourlyRate: 41,
        isAvailable: true,
        avatarUrl:
            'https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=150&h=150&fit=crop&crop=face',
        availableSlots: [
          '08:00 AM',
          '09:00 AM',
          '11:00 AM',
          '01:00 PM',
          '03:00 PM',
          '06:00 PM'
        ],
      ),
      Tutor(
        id: '10',
        name: 'Ms. Jennifer Lee',
        subject: 'English',
        rating: 4.6,
        hourlyRate: 39,
        isAvailable: true,
        avatarUrl:
            'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150&h=150&fit=crop&crop=face',
        availableSlots: [
          '10:00 AM',
          '12:00 PM',
          '02:00 PM',
          '04:00 PM',
          '05:00 PM'
        ],
      ),
    ];
  }

  /// Get tutors filtered by subject
  static List<Tutor> getTutorsBySubject(String subject) {
    if (subject == 'All') return getTutors();
    return getTutors().where((tutor) => tutor.subject == subject).toList();
  }

  /// Search tutors by name or subject
  static List<Tutor> searchTutors(String query) {
    final tutors = getTutors();
    if (query.isEmpty) return tutors;

    return tutors.where((tutor) {
      final name = tutor.name.toLowerCase();
      final subject = tutor.subject.toLowerCase();
      final searchQuery = query.toLowerCase();

      return name.contains(searchQuery) || subject.contains(searchQuery);
    }).toList();
  }
}
