import '../models/tutor.dart';
import '../models/booking.dart';
import 'tutor_service.dart';

class BookingService {
  static final BookingService _instance = BookingService._internal();
  factory BookingService() => _instance;
  BookingService._internal();

  static BookingService get instance => _instance;

  final List<BookingItem> _bookings = [];

  void addBooking(Tutor tutor) {
    final booking = BookingItem(
      tutor: tutor,
      dateTime: DateTime.now().add(const Duration(days: 1)),
    );
    _bookings.add(booking);
  }

  List<BookingItem> getBookings() {
    return List.from(_bookings);
  }

  int getBookingsCount() {
    return _bookings.length;
  }

  void removeBooking(Tutor tutor) {
    _bookings.removeWhere((booking) => booking.tutor.id == tutor.id);
  }

  // NEW METHOD: Get all bookings with sample data
  List<Booking> getAllBookings() {
    final sampleBookings = <Booking>[];
    final tutors = TutorService.getTutors();

    // Generate sample bookings for demo
    for (int i = 0; i < tutors.length && i < 6; i++) {
      final tutor = tutors[i];

      // Add upcoming booking
      sampleBookings.add(Booking(
        id: 'booking_${i}_upcoming',
        tutor: tutor,
        dateTime: DateTime.now().add(Duration(days: i + 1, hours: 2)),
        status: 'upcoming',
        notes: 'Growth session with ${tutor.name} - ${tutor.subject}',
      ));

      // Add some completed bookings for first 3 tutors
      if (i < 3) {
        sampleBookings.add(Booking(
          id: 'booking_${i}_completed',
          tutor: tutor,
          dateTime: DateTime.now().subtract(Duration(days: i + 2, hours: 1)),
          status: 'completed',
          notes: 'Completed learning session in ${tutor.subject}',
        ));
      }

      // Add today's sessions for first 2 tutors
      if (i < 2) {
        sampleBookings.add(Booking(
          id: 'booking_${i}_today',
          tutor: tutor,
          dateTime: DateTime.now().add(Duration(hours: i + 3)),
          status: 'today',
          notes: 'Today\'s growth session',
        ));
      }
    }

    // Add current bookings from the existing service
    sampleBookings.addAll(_bookings
        .map((bookingItem) => Booking(
              id: 'current_${bookingItem.tutor.id}',
              tutor: bookingItem.tutor,
              dateTime: bookingItem.dateTime,
              status: 'active',
              notes: 'Active booking',
            ))
        .toList());

    return sampleBookings;
  }
}

// Keep the existing BookingItem class for backward compatibility
class BookingItem {
  final Tutor tutor;
  final DateTime dateTime;

  const BookingItem({
    required this.tutor,
    required this.dateTime,
  });
}
