import 'tutor.dart'; // FIXED: Added missing import

class Booking {
  final String id;
  final Tutor tutor;
  final DateTime dateTime;
  final String status;
  final String notes;

  const Booking({
    required this.id,
    required this.tutor,
    required this.dateTime,
    this.status = 'upcoming',
    this.notes = '',
  });

  bool get isUpcoming => dateTime.isAfter(DateTime.now());
  bool get isPast => dateTime.isBefore(DateTime.now());
}
