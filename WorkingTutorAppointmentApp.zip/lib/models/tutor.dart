/// Enhanced Tutor model with available time slots and profile information
class Tutor {
  final String id;
  final String name;
  final String subject;
  final double rating;
  final double hourlyRate;
  final bool isAvailable;
  final String avatarUrl;
  final List<String> availableSlots;

  Tutor({
    required this.id,
    required this.name,
    required this.subject,
    required this.rating,
    required this.hourlyRate,
    required this.isAvailable,
    required this.avatarUrl,
    required this.availableSlots,
  });

  /// Create a copy of this tutor with some properties changed
  Tutor copyWith({
    String? id,
    String? name,
    String? subject,
    double? rating,
    double? hourlyRate,
    bool? isAvailable,
    String? avatarUrl,
    List<String>? availableSlots,
  }) {
    return Tutor(
      id: id ?? this.id,
      name: name ?? this.name,
      subject: subject ?? this.subject,
      rating: rating ?? this.rating,
      hourlyRate: hourlyRate ?? this.hourlyRate,
      isAvailable: isAvailable ?? this.isAvailable,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      availableSlots: availableSlots ?? this.availableSlots,
    );
  }

  /// Convert tutor to JSON for API integration
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'subject': subject,
      'rating': rating,
      'hourlyRate': hourlyRate,
      'isAvailable': isAvailable,
      'avatarUrl': avatarUrl,
      'availableSlots': availableSlots,
    };
  }

  /// Create tutor from JSON data
  factory Tutor.fromJson(Map<String, dynamic> json) {
    return Tutor(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      subject: json['subject'] ?? '',
      rating: (json['rating'] ?? 0.0).toDouble(),
      hourlyRate: (json['hourlyRate'] ?? 0.0).toDouble(),
      isAvailable: json['isAvailable'] ?? false,
      avatarUrl: json['avatarUrl'] ?? '',
      availableSlots: List<String>.from(json['availableSlots'] ?? []),
    );
  }

  @override
  String toString() {
    return 'Tutor(id: $id, name: $name, subject: $subject, rating: $rating, hourlyRate: $hourlyRate, isAvailable: $isAvailable, avatarUrl: $avatarUrl, availableSlots: $availableSlots)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is Tutor &&
        other.id == id &&
        other.name == name &&
        other.subject == subject &&
        other.rating == rating &&
        other.hourlyRate == hourlyRate &&
        other.isAvailable == isAvailable &&
        other.avatarUrl == avatarUrl &&
        _listEquals(other.availableSlots, availableSlots);
  }

  @override
  int get hashCode {
    return id.hashCode ^
        name.hashCode ^
        subject.hashCode ^
        rating.hashCode ^
        hourlyRate.hashCode ^
        isAvailable.hashCode ^
        avatarUrl.hashCode ^
        availableSlots.hashCode;
  }

  /// Helper method to compare lists
  bool _listEquals<T>(List<T>? a, List<T>? b) {
    if (a == null) return b == null;
    if (b == null || a.length != b.length) return false;
    if (identical(a, b)) return true;
    for (int index = 0; index < a.length; index += 1) {
      if (a[index] != b[index]) return false;
    }
    return true;
  }
}
