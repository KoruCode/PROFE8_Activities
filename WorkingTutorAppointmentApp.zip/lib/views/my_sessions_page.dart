import 'package:flutter/material.dart';
import '../models/tutor.dart';
import '../models/booking.dart';
import '../services/tutor_service.dart';
import '../services/booking_service.dart';

class SessionsPage extends StatefulWidget {
  final Function(int)? onNavigationChanged;

  const SessionsPage({
    super.key,
    this.onNavigationChanged,
  });

  @override
  State<SessionsPage> createState() => _SessionsPageState();
}

class _SessionsPageState extends State<SessionsPage>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  List<SessionData> sessions = [];
  String _selectedFilter = 'All';
  final List<String> _filters = [
    'All',
    'Today',
    'This Week',
    'Upcoming',
    'Completed'
  ];

  // TutorGrow Color Palette
  static const Color primaryGreen = Color(0xFF2E7D32);
  static const Color lightGreen = Color(0xFFA5D6A7);
  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color accentGreen = Color(0xFF66BB6A);
  static const Color backgroundGreen = Color(0xFFF1F8E9);
  static const Color cardGreen = Color(0xFFE8F5E8);

  // Responsive breakpoints
  bool get isMobile => MediaQuery.of(context).size.width < 768;
  bool get isTablet =>
      MediaQuery.of(context).size.width >= 768 &&
      MediaQuery.of(context).size.width < 1200;
  bool get isDesktop => MediaQuery.of(context).size.width >= 1200;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _loadSessions();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _loadSessions() {
    final tutors = TutorService.getTutors();
    sessions = _generateSampleSessions(tutors);
    _animationController.forward();
  }

  List<SessionData> _generateSampleSessions(List<Tutor> tutors) {
    final List<SessionData> sampleSessions = [];
    final now = DateTime.now();

    // Today's sessions
    sampleSessions.addAll([
      SessionData(
        id: 'session_today_1',
        tutor: tutors[0],
        subject: tutors[0].subject,
        dateTime: now.add(const Duration(hours: 2)),
        duration: 60,
        status: 'upcoming',
        price: tutors[0].hourlyRate,
        notes: 'Review calculus derivatives and integration techniques',
        sessionType: 'Video Call',
      ),
      SessionData(
        id: 'session_today_2',
        tutor: tutors[1],
        subject: tutors[1].subject,
        dateTime: now.add(const Duration(hours: 4)),
        duration: 90,
        status: 'upcoming',
        price: tutors[1].hourlyRate,
        notes: 'Physics momentum and energy conservation',
        sessionType: 'In-Person',
      ),
    ]);

    // This week's sessions
    for (int i = 1; i <= 5; i++) {
      sampleSessions.add(
        SessionData(
          id: 'session_week_$i',
          tutor: tutors[i % tutors.length],
          subject: tutors[i % tutors.length].subject,
          dateTime: now.add(Duration(days: i, hours: 10 + (i % 8))),
          duration: [60, 90, 120][i % 3],
          status: 'upcoming',
          price: tutors[i % tutors.length].hourlyRate,
          notes: 'Growing knowledge in ${tutors[i % tutors.length].subject}',
          sessionType: i % 2 == 0 ? 'Video Call' : 'In-Person',
        ),
      );
    }

    // Completed sessions
    for (int i = 0; i < 4; i++) {
      sampleSessions.add(
        SessionData(
          id: 'session_completed_$i',
          tutor: tutors[i % tutors.length],
          subject: tutors[i % tutors.length].subject,
          dateTime: now.subtract(Duration(days: i + 1, hours: 2)),
          duration: [60, 90][i % 2],
          status: 'completed',
          price: tutors[i % tutors.length].hourlyRate,
          notes: 'Completed session - Great progress made!',
          sessionType: 'Video Call',
          rating: 4.5 + (i % 2) * 0.3,
        ),
      );
    }

    return sampleSessions;
  }

  List<SessionData> get filteredSessions {
    switch (_selectedFilter) {
      case 'Today':
        return sessions.where((s) => _isToday(s.dateTime)).toList();
      case 'This Week':
        return sessions.where((s) => _isThisWeek(s.dateTime)).toList();
      case 'Upcoming':
        return sessions
            .where((s) => s.dateTime.isAfter(DateTime.now()))
            .toList();
      case 'Completed':
        return sessions.where((s) => s.status == 'completed').toList();
      default:
        return sessions;
    }
  }

  bool _isToday(DateTime date) {
    final today = DateTime.now();
    return date.year == today.year &&
        date.month == today.month &&
        date.day == today.day;
  }

  bool _isThisWeek(DateTime date) {
    final now = DateTime.now();
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final weekEnd = weekStart.add(const Duration(days: 6));
    return date.isAfter(weekStart) && date.isBefore(weekEnd);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundGreen,
      appBar: _buildTutorGrowAppBar(),
      drawer: _buildTutorGrowSidebar(),
      body: _buildSessionsContent(),
      floatingActionButton: _buildAddSessionButton(),
    );
  }

  PreferredSizeWidget _buildTutorGrowAppBar() {
    return AppBar(
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              color: lightGreen,
              shape: BoxShape.circle,
            ),
            child:
                const Icon(Icons.calendar_today, color: primaryGreen, size: 24),
          ),
          const SizedBox(width: 12),
          const Text('Learning Sessions',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
      backgroundColor: primaryGreen,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8),
          child: IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.add_circle_outline, color: Colors.white),
            ),
            onPressed: () => _showNewSessionDialog(),
          ),
        ),
      ],
    );
  }

  // ACTIVITY #3: Container with padding, margin, and background color around Text
  Widget _buildTutorGrowSidebar() {
    return Drawer(
      backgroundColor: cardGreen,
      child: Column(
        children: [
          Container(
            height: 200,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [primaryGreen, accentGreen],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        color: lightGreen,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: darkGreen.withValues(alpha: 0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.schedule,
                        size: 35,
                        color: primaryGreen,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Learning Sessions',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const Text(
                      'Nurture Your Growth',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: cardGreen,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  // Page Navigation
                  _buildSidebarSection('Navigation'),
                  _buildGreenSidebarItem(
                      Icons.home,
                      'Grow',
                      'Find tutors to grow',
                      () => widget.onNavigationChanged?.call(0)),
                  _buildGreenSidebarItem(
                      Icons.calendar_today,
                      'Sessions',
                      'Your learning sessions',
                      () => widget.onNavigationChanged?.call(1)),
                  _buildGreenSidebarItem(
                      Icons.chat_bubble,
                      'Chat',
                      'Message your tutors',
                      () => widget.onNavigationChanged?.call(2)),
                  _buildGreenSidebarItem(
                      Icons.person,
                      'Profile',
                      'Your growth profile',
                      () => widget.onNavigationChanged?.call(3)),

                  const SizedBox(height: 20),

                  // ACTIVITY #2: Two buttons in Column, centered vertically and horizontally
                  _buildQuickGrowthActions(),

                  const SizedBox(height: 20),
                  _buildSidebarSection('Session Management'),
                  _buildGreenSidebarItem(Icons.schedule, 'Today\'s Growth',
                      'View today\'s sessions', () => _setFilter('Today')),
                  _buildGreenSidebarItem(Icons.date_range, 'This Week',
                      'Weekly learning plan', () => _setFilter('This Week')),
                  _buildGreenSidebarItem(
                      Icons.trending_up,
                      'Progress Report',
                      'Track your growth',
                      () => _showSnackBar('Progress blooming! 📈')),

                  const SizedBox(height: 20),
                  _buildSidebarSection('Learning Tools'),
                  _buildGreenSidebarItem(
                      Icons.note_add,
                      'Session Notes',
                      'Review your notes',
                      () => _showSnackBar('Notes flourishing! 📝')),
                  _buildGreenSidebarItem(
                      Icons.star_outline,
                      'Rate Sessions',
                      'Share your experience',
                      () => _showSnackBar('Ratings growing! ⭐')),
                  _buildGreenSidebarItem(
                      Icons.timeline,
                      'Learning Path',
                      'Your growth timeline',
                      () => _showSnackBar('Path expanding! 🛤️')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ACTIVITY #2: Two buttons in a Column, centered vertically and horizontally
  Widget _buildQuickGrowthActions() {
    return Container(
      margin: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 8), // ACTIVITY #3: Margin
      padding: const EdgeInsets.all(20), // ACTIVITY #3: Padding
      decoration: BoxDecoration(
        // ACTIVITY #3: Background color
        color: Colors.white.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center, // ACTIVITY #2: Centered vertically
        crossAxisAlignment:
            CrossAxisAlignment.center, // ACTIVITY #2: Centered horizontally
        children: [
          // ACTIVITY #3: Container with padding, margin, background color around Text
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 6), // ACTIVITY #3: Padding
            margin: const EdgeInsets.only(bottom: 16), // ACTIVITY #3: Margin
            decoration: BoxDecoration(
              // ACTIVITY #3: Background color
              color: lightGreen.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.eco, color: primaryGreen, size: 16),
                SizedBox(width: 6),
                Text(
                  'Quick Growth Actions',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: darkGreen,
                  ),
                ),
              ],
            ),
          ),

          // ACTIVITY #2: Two buttons in Column, centered
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.add_circle_outline),
              label: const Text('Schedule New Session'),
              onPressed: () {
                Navigator.pop(context);
                _showNewSessionDialog();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12), // Spacing between buttons
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.insights),
              label: const Text('View Growth Report'),
              onPressed: () {
                Navigator.pop(context);
                _showGrowthReport();
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: primaryGreen,
                side: const BorderSide(color: primaryGreen),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebarSection(String title) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      child: Row(
        children: [
          const Icon(Icons.nature, size: 16, color: darkGreen),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: darkGreen,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGreenSidebarItem(
      IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.6),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: lightGreen.withValues(alpha: 0.4),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: primaryGreen, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: darkGreen,
                        ),
                      ),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 11,
                          color: primaryGreen.withValues(alpha: 0.7),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: accentGreen, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSessionsContent() {
    return Container(
      color: backgroundGreen,
      child: Column(
        children: [
          _buildGrowthStatsHeader(), // ACTIVITY 7 & 8: Stack + Flexible
          _buildFilterNavigation(), // ACTIVITY 6: Row navigation
          Expanded(child: _buildSessionsList()), // ACTIVITY 10: Custom layout
        ],
      ),
    );
  }

  // ACTIVITY 7: Stack layout with background and floating elements
  // ACTIVITY 8: Flexible inside Column for orientation changes
  Widget _buildGrowthStatsHeader() {
    return Container(
      margin: EdgeInsets.all(isMobile ? 16 : 24),
      height: isMobile ? 140 : 160,
      child: Stack(
        // ACTIVITY #7: Stack layout
        children: [
          // ACTIVITY #7: Background with green growth theme
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  accentGreen.withValues(alpha: 0.8),
                  primaryGreen.withValues(alpha: 0.9),
                  darkGreen.withValues(alpha: 0.8),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: accentGreen.withValues(alpha: 0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
          ),

          // Content with growth theme
          Positioned.fill(
            child: Container(
              padding: EdgeInsets.all(isMobile ? 16 : 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.spa,
                                    color: Colors.white, size: 20),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Text(
                                    'Sessions Growing',
                                    style: TextStyle(
                                      fontSize: isMobile ? 18 : 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text(
                              'Your learning is flourishing! 🌱',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.white.withValues(alpha: 0.9),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          '${filteredSessions.length}',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const Spacer(),

                  // ACTIVITY 8: Flexible widgets for growth stats
                  _buildGrowthStatsSection(),
                ],
              ),
            ),
          ),

          // ACTIVITY 7: Floating progress indicator
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: lightGreen,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: darkGreen.withValues(alpha: 0.2),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child:
                  const Icon(Icons.trending_up, color: primaryGreen, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // ACTIVITY 8: Flexible inside Column for dynamic growth stats
  Widget _buildGrowthStatsSection() {
    final today = filteredSessions.where((s) => _isToday(s.dateTime)).length;
    final upcoming = filteredSessions
        .where((s) => s.dateTime.isAfter(DateTime.now()))
        .length;
    final completed =
        filteredSessions.where((s) => s.status == 'completed').length;

    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 280) {
          // Wide layout: Row with Flexible widgets
          return Row(
            children: [
              Flexible(
                  flex: 1,
                  child: _buildGrowthStatCard('$today', 'Today\'s Growth',
                      Icons.today)), // ACTIVITY #8: Flexible
              const SizedBox(width: 8),
              Flexible(
                  flex: 1,
                  child: _buildGrowthStatCard('$upcoming', 'Seeds Planted',
                      Icons.schedule)), // ACTIVITY #8: Flexible
              const SizedBox(width: 8),
              Flexible(
                  flex: 1,
                  child: _buildGrowthStatCard('$completed', 'Harvested',
                      Icons.check_circle)), // ACTIVITY #8: Flexible
            ],
          );
        } else {
          // Narrow layout: Column with Flexible widgets
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                      child:
                          _buildGrowthStatCard('$today', 'Today', Icons.today)),
                  const SizedBox(width: 6),
                  Expanded(
                      child: _buildGrowthStatCard(
                          '$upcoming', 'Upcoming', Icons.schedule)),
                ],
              ),
              const SizedBox(height: 6),
              _buildGrowthStatCard(
                  '$completed', 'Completed', Icons.check_circle),
            ],
          );
        }
      },
    );
  }

  Widget _buildGrowthStatCard(String value, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 12),
          const SizedBox(height: 2),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 8,
              color: Colors.white.withValues(alpha: 0.9),
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // ACTIVITY 6: Navigation bar using Row with icons spaced evenly
  Widget _buildFilterNavigation() {
    return Container(
      height: 60,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        // ACTIVITY #6: Row with even spacing
        mainAxisAlignment:
            MainAxisAlignment.spaceEvenly, // ACTIVITY #6: Even spacing
        children: _filters.map((filter) {
          final isSelected = _selectedFilter == filter;
          return Expanded(
            child: GestureDetector(
              onTap: () => _setFilter(filter),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 2),
                decoration: BoxDecoration(
                  color: isSelected ? primaryGreen : cardGreen,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: primaryGreen.withValues(alpha: 0.3),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _getFilterIcon(filter),
                        color: isSelected ? Colors.white : primaryGreen,
                        size: 18,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        filter,
                        style: TextStyle(
                          fontSize: 11,
                          color: isSelected ? Colors.white : primaryGreen,
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.w500,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  IconData _getFilterIcon(String filter) {
    switch (filter) {
      case 'All':
        return Icons.apps;
      case 'Today':
        return Icons.today;
      case 'This Week':
        return Icons.date_range;
      case 'Upcoming':
        return Icons.schedule;
      case 'Completed':
        return Icons.check_circle;
      default:
        return Icons.filter_list;
    }
  }

  Widget _buildSessionsList() {
    if (filteredSessions.isEmpty) {
      return _buildEmptyGrowthState();
    }

    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return FadeTransition(
          opacity: _animationController,
          child: Container(
            color: backgroundGreen,
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 16 : 24),
            child: _buildCustomSessionGrid(),
          ),
        );
      },
    );
  }

  // ACTIVITY 10: Both Row and Column in same widget tree for session layout
  Widget _buildCustomSessionGrid() {
    final columns = isMobile ? 1 : (isTablet ? 2 : 3);
    final rows = (filteredSessions.length / columns).ceil();

    return SingleChildScrollView(
      child: Column(
        // ACTIVITY #10: Column
        children: List.generate(rows, (rowIndex) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              // ACTIVITY #10: Row
              crossAxisAlignment: CrossAxisAlignment.start,
              children: List.generate(columns, (colIndex) {
                final sessionIndex = rowIndex * columns + colIndex;
                if (sessionIndex >= filteredSessions.length) {
                  return Expanded(child: Container());
                }
                return Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(
                      right: colIndex < columns - 1 ? 12 : 0,
                      left: colIndex > 0 ? 12 : 0,
                    ),
                    child:
                        _buildGrowthSessionCard(filteredSessions[sessionIndex]),
                  ),
                );
              }),
            ),
          );
        }),
      ),
    );
  }

  // ACTIVITY #4: Profile card layout with Row (tutor info) and Column (session details)
  Widget _buildGrowthSessionCard(SessionData session) {
    final isUpcoming = session.dateTime.isAfter(DateTime.now());
    final isPast = session.status == 'completed';

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.15),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Column(
          children: [
            // Status indicator bar
            Container(
              width: double.infinity,
              height: 4,
              color: isUpcoming
                  ? accentGreen
                  : (isPast ? primaryGreen : lightGreen),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ACTIVITY 4: Row for tutor profile info
                  Row(
                    // ACTIVITY #4: Row layout
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: accentGreen.withValues(alpha: 0.2),
                              blurRadius: 6,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(24),
                          child: Image.network(
                            session.tutor.avatarUrl,
                            width: 48,
                            height: 48,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                color: lightGreen.withValues(alpha: 0.3),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.person,
                                size: 24,
                                color: primaryGreen,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),

                      Expanded(
                        child: Column(
                          // ACTIVITY #4: Column for details
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              session.tutor.name,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: darkGreen,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 2),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: lightGreen.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.eco,
                                      size: 10, color: primaryGreen),
                                  const SizedBox(width: 4),
                                  Text(
                                    session.subject,
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: primaryGreen,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Status icon
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: (isUpcoming ? accentGreen : primaryGreen)
                              .withValues(alpha: 0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          isUpcoming
                              ? Icons.schedule
                              : (isPast ? Icons.check_circle : Icons.today),
                          size: 16,
                          color: isUpcoming ? accentGreen : primaryGreen,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Session details
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildSessionDetailRow(
                        Icons.calendar_today,
                        '${session.dateTime.day}/${session.dateTime.month}/${session.dateTime.year}',
                      ),
                      const SizedBox(height: 8),
                      _buildSessionDetailRow(
                        Icons.access_time,
                        '${session.dateTime.hour.toString().padLeft(2, '0')}:${session.dateTime.minute.toString().padLeft(2, '0')} (${session.duration} min)',
                      ),
                      const SizedBox(height: 8),
                      _buildSessionDetailRow(
                        Icons.video_call,
                        session.sessionType,
                      ),
                      const SizedBox(height: 8),
                      _buildSessionDetailRow(
                        Icons.attach_money,
                        '\$${session.price.toInt()}',
                      ),
                      if (session.rating != null) ...[
                        const SizedBox(height: 8),
                        _buildSessionDetailRow(
                          Icons.star,
                          '${session.rating} stars',
                        ),
                      ],
                    ],
                  ),

                  if (session.notes.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: backgroundGreen,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        session.notes,
                        style: TextStyle(
                          fontSize: 12,
                          color: darkGreen.withValues(alpha: 0.8),
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 16),

                  // Action button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => _handleSessionAction(session),
                      icon: Icon(_getSessionActionIcon(session)),
                      label: Text(_getSessionActionText(session)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            isUpcoming ? accentGreen : primaryGreen,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionDetailRow(IconData icon, String text) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: lightGreen.withValues(alpha: 0.2),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 12, color: primaryGreen),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 12,
              color: darkGreen.withValues(alpha: 0.8),
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyGrowthState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              color: lightGreen.withValues(alpha: 0.2),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.eco,
              size: 50,
              color: accentGreen,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'No Sessions Growing Yet',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: darkGreen,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Plant your first learning session to start growing!',
            style: TextStyle(
              fontSize: 14,
              color: primaryGreen.withValues(alpha: 0.8),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _showNewSessionDialog,
            icon: const Icon(Icons.add),
            label: const Text('Schedule Session'),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryGreen,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddSessionButton() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [accentGreen, primaryGreen],
        ),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: primaryGreen.withValues(alpha: 0.3),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: FloatingActionButton(
        onPressed: _showNewSessionDialog,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        child: const Icon(Icons.add, size: 28),
      ),
    );
  }

  IconData _getSessionActionIcon(SessionData session) {
    final isUpcoming = session.dateTime.isAfter(DateTime.now());
    final isPast = session.status == 'completed';

    if (isUpcoming) return Icons.launch;
    if (isPast) return Icons.rate_review;
    return Icons.join_full;
  }

  String _getSessionActionText(SessionData session) {
    final isUpcoming = session.dateTime.isAfter(DateTime.now());
    final isPast = session.status == 'completed';

    if (isUpcoming) return 'Join Session';
    if (isPast) return 'Rate & Review';
    return 'Join Now';
  }

  void _setFilter(String filter) {
    setState(() {
      _selectedFilter = filter;
    });
  }

  void _handleSessionAction(SessionData session) {
    final isUpcoming = session.dateTime.isAfter(DateTime.now());
    final isPast = session.status == 'completed';

    if (isUpcoming) {
      _showSnackBar('🌱 Joining growth session with ${session.tutor.name}!');
    } else if (isPast) {
      _showRatingDialog(session);
    } else {
      _showSnackBar('🌿 Joining learning session now!');
    }
  }

  void _showNewSessionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.add_circle, color: primaryGreen),
            SizedBox(width: 8),
            Text('Schedule New Session', style: TextStyle(color: darkGreen)),
          ],
        ),
        content: const Text(
          'Ready to grow your knowledge? Let\'s schedule a new learning session!',
          style: TextStyle(color: darkGreen),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Later', style: TextStyle(color: primaryGreen)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              widget.onNavigationChanged?.call(0); // Go to tutors page
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryGreen,
              foregroundColor: Colors.white,
            ),
            child: const Text('Find Tutor'),
          ),
        ],
      ),
    );
  }

  void _showRatingDialog(SessionData session) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.star, color: accentGreen),
            SizedBox(width: 8),
            Text('Rate Your Growth', style: TextStyle(color: darkGreen)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'How was your session with ${session.tutor.name}?',
              style: const TextStyle(color: darkGreen),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(5, (index) {
                return IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _showSnackBar('Thanks for growing with us! ⭐');
                  },
                  icon: const Icon(
                    Icons.eco,
                    color: accentGreen,
                    size: 28,
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  void _showGrowthReport() {
    _showSnackBar(
        '📊 Your learning is flourishing! Growth report blooming soon! 🌱');
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: primaryGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

// Session Data Model for dummy content
class SessionData {
  final String id;
  final Tutor tutor;
  final String subject;
  final DateTime dateTime;
  final int duration; // in minutes
  final String status;
  final double price;
  final String notes;
  final String sessionType;
  final double? rating;

  SessionData({
    required this.id,
    required this.tutor,
    required this.subject,
    required this.dateTime,
    required this.duration,
    required this.status,
    required this.price,
    required this.notes,
    required this.sessionType,
    this.rating,
  });
}
