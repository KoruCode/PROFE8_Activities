import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  final Function(int)? onNavigationChanged;

  const ProfilePage({
    super.key,
    this.onNavigationChanged,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  late AnimationController _animationController;

  // TutorGrow Color Palette
  static const Color primaryGreen = Color(0xFF2E7D32);
  static const Color lightGreen = Color(0xFFA5D6A7);
  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color accentGreen = Color(0xFF66BB6A);
  static const Color backgroundGreen = Color(0xFFF1F8E9);
  static const Color cardGreen = Color(0xFFE8F5E8);

  // User data
  final String userName = "Alex Growth";
  final String userEmail = "alex.growth@tutorgrow.com";
  final String userPhone = "+1 (555) 123-4567";
  final String userBio = "Growing my knowledge one session at a time 🌱";
  final String joinDate = "Member since January 2024";

  // Growth stats data
  final Map<String, dynamic> growthStats = {
    'totalSessions': 15,
    'completedSessions': 12,
    'upcomingSessions': 3,
    'favoriteTutors': 4,
    'averageRating': 4.8,
    'totalHoursLearned': 24,
    'currentStreak': 7,
    'achievements': 6,
  };

  bool get isMobile => MediaQuery.of(context).size.width < 768;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundGreen,
      appBar: _buildTutorGrowAppBar(),
      drawer: _buildTutorGrowSidebar(),
      body: _buildProfileContent(),
    );
  }

  PreferredSizeWidget _buildTutorGrowAppBar() {
    return AppBar(
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              color: lightGreen,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.person, color: primaryGreen, size: 24),
          ),
          const SizedBox(width: 12),
          const Text('Growth Profile',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
      backgroundColor: primaryGreen,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8),
          child: IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.edit, color: Colors.white),
            ),
            onPressed: () => _showEditDialog(),
          ),
        ),
      ],
    );
  }

  // ACTIVITY #3: Container with padding, margin, and background color around Text
  Widget _buildTutorGrowSidebar() {
    return Drawer(
      backgroundColor: cardGreen,
      child: Column(
        children: [
          Container(
            height: 220,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [primaryGreen, accentGreen],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: lightGreen,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: darkGreen.withValues(alpha: 0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.account_circle,
                        size: 40,
                        color: primaryGreen,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Growth Profile',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const Text(
                      'Cultivate Your Identity',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: cardGreen,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  // Page Navigation
                  _buildTutorGrowSection('Navigation'),
                  _buildTutorGrowSidebarItem(
                      Icons.home,
                      'Grow',
                      'Find tutors to grow',
                      () => widget.onNavigationChanged?.call(0)),
                  _buildTutorGrowSidebarItem(
                      Icons.calendar_today,
                      'Sessions',
                      'Your learning sessions',
                      () => widget.onNavigationChanged?.call(1)),
                  _buildTutorGrowSidebarItem(
                      Icons.chat_bubble,
                      'Chat',
                      'Message your tutors',
                      () => widget.onNavigationChanged?.call(2)),
                  _buildTutorGrowSidebarItem(
                      Icons.person,
                      'Profile',
                      'Your growth profile',
                      () => widget.onNavigationChanged?.call(3)),

                  const SizedBox(height: 24),

                  // ACTIVITY #2: Two buttons in Column, centered vertically and horizontally
                  _buildQuickProfileActions(),

                  const SizedBox(height: 24),
                  _buildTutorGrowSection('Growth Settings'),
                  _buildTutorGrowSidebarItem(Icons.edit, 'Edit Profile',
                      'Update your info', _showEditDialog),
                  _buildTutorGrowSidebarItem(
                      Icons.security,
                      'Privacy',
                      'Manage privacy settings',
                      () => _showSnackBar('Privacy settings growing! 🔒')),
                  _buildTutorGrowSidebarItem(
                      Icons.notifications,
                      'Notifications',
                      'Manage alerts',
                      () => _showSnackBar('Notifications blooming! 🔔')),

                  const SizedBox(height: 20),
                  _buildTutorGrowSection('Learning Journey'),
                  _buildTutorGrowSidebarItem(Icons.school, 'Achievements',
                      'View your progress', () => _showAchievements()),
                  _buildTutorGrowSidebarItem(
                      Icons.history,
                      'Learning History',
                      'Past sessions',
                      () => _showSnackBar('History growing! 📚')),
                  _buildTutorGrowSidebarItem(
                      Icons.favorite,
                      'Favorite Tutors',
                      'Your preferred mentors',
                      () => _showSnackBar('Favorites blooming! ⭐')),

                  const SizedBox(height: 20),
                  _buildTutorGrowSection('Support'),
                  _buildTutorGrowSidebarItem(Icons.help, 'Help Center',
                      'Get assistance', () => _showSnackBar('Help growing! ❓')),
                  _buildTutorGrowSidebarItem(
                      Icons.feedback,
                      'Feedback',
                      'Share your thoughts',
                      () => _showSnackBar('Feedback flourishing! 💭')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ACTIVITY #2: Two buttons in a Column, centered vertically and horizontally
  Widget _buildQuickProfileActions() {
    return Container(
      margin: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 8), // ACTIVITY #3: Margin
      padding: const EdgeInsets.all(20), // ACTIVITY #3: Padding
      decoration: BoxDecoration(
        // ACTIVITY #3: Background color
        color: Colors.white.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          // FIXED: BoxShadow instead of BoxShadient
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center, // ACTIVITY #2: Centered vertically
        crossAxisAlignment:
            CrossAxisAlignment.center, // ACTIVITY #2: Centered horizontally
        children: [
          // ACTIVITY #3: Container with padding, margin, background color around Text
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 6), // ACTIVITY #3: Padding
            margin: const EdgeInsets.only(bottom: 16), // ACTIVITY #3: Margin
            decoration: BoxDecoration(
              // ACTIVITY #3: Background color
              color: lightGreen.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.eco, color: primaryGreen, size: 16),
                SizedBox(width: 6),
                Text(
                  'Quick Profile Actions',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: darkGreen,
                  ),
                ),
              ],
            ),
          ),

          // ACTIVITY #2: Two buttons in Column, centered
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text('Cultivate Profile'),
              onPressed: () {
                Navigator.pop(context);
                _showEditDialog();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12), // Spacing between buttons
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.settings),
              label: const Text('Growth Settings'),
              onPressed: () {
                Navigator.pop(context);
                _showSettings();
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: primaryGreen,
                side: const BorderSide(color: primaryGreen, width: 2),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTutorGrowSection(String title) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.bold,
          color: darkGreen,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  // ACTIVITY #3: Container with padding, margin, and background color around Text
  Widget _buildTutorGrowSidebarItem(
      IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 4), // ACTIVITY #3: Margin
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(16), // ACTIVITY #3: Padding
            decoration: BoxDecoration(
              // ACTIVITY #3: Background color
              color: Colors.white.withValues(alpha: 0.7),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: accentGreen.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: lightGreen.withValues(alpha: 0.3),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    color: primaryGreen,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ACTIVITY #3: Text widget with container styling
                      Text(
                        title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: darkGreen,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 12,
                          color: primaryGreen.withValues(alpha: 0.8),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: accentGreen.withValues(alpha: 0.6),
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileContent() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildProfileHeader(), // ACTIVITY 4 & 7: Profile card + Stack
          _buildGrowthStats(), // ACTIVITY 1 & 8: Three stats + Flexible
          _buildProfileDetails(), // ACTIVITY 10: Row and Column layout
          _buildProfileActions(),
        ],
      ),
    );
  }

  // ACTIVITY #4: Profile card layout with Row (profile picture + name) and Column (details)
  // ACTIVITY #7: Stack layout with background and floating elements
  Widget _buildProfileHeader() {
    return Container(
      margin: const EdgeInsets.all(16),
      child: Stack(
        // ACTIVITY #7: Stack layout
        children: [
          // ACTIVITY #7: Background with growth gradient
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(
                colors: [accentGreen, primaryGreen, darkGreen],
              ),
              boxShadow: [
                BoxShadow(
                  color: accentGreen.withValues(alpha: 0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            // ACTIVITY #4: Row for profile picture + name, then Column for details
            child: Row(
              // ACTIVITY #4: Row layout
              children: [
                // Profile picture with growth theme
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: lightGreen,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 4),
                    boxShadow: [
                      BoxShadow(
                        color: darkGreen.withValues(alpha: 0.3),
                        blurRadius: 15,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.person,
                    size: 50,
                    color: primaryGreen,
                  ),
                ),
                const SizedBox(width: 20),

                // Name and details
                Expanded(
                  child: Column(
                    // ACTIVITY #4: Column for details
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        userName,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        userBio,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white.withValues(alpha: 0.9),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.verified, color: Colors.white, size: 16),
                            SizedBox(width: 6),
                            Text(
                              'Verified Learner',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        joinDate,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white.withValues(alpha: 0.7),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ACTIVITY #7: Floating verified badge
          Positioned(
            top: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: lightGreen,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: darkGreen.withValues(alpha: 0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.verified, color: primaryGreen, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ACTIVITY #1: Three Text widgets in Row with equal spacing
  // ACTIVITY #8: Flexible inside Column for dynamic growth stats
  Widget _buildGrowthStats() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: LayoutBuilder(
        builder: (context, constraints) {
          // ACTIVITY #8: Flexible widgets for orientation changes
          if (constraints.maxWidth > 600) {
            // Wide layout: Row with three main stats
            return Row(
              // ACTIVITY #1: Row with three Text widgets
              mainAxisAlignment:
                  MainAxisAlignment.spaceEvenly, // ACTIVITY #1: Equal spacing
              children: [
                Flexible(
                    flex: 1,
                    child: _buildMainStatCard(
                        '${growthStats['totalSessions']}',
                        'Total\nSessions',
                        Icons.school)), // ACTIVITY #8: Flexible
                const SizedBox(width: 12),
                Flexible(
                    flex: 1,
                    child: _buildMainStatCard(
                        '${growthStats['averageRating']}⭐',
                        'Growth\nRating',
                        Icons.star)), // ACTIVITY #8: Flexible
                const SizedBox(width: 12),
                Flexible(
                    flex: 1,
                    child: _buildMainStatCard(
                        '${growthStats['currentStreak']}',
                        'Day\nStreak',
                        Icons.local_fire_department)), // ACTIVITY #8: Flexible
              ],
            );
          } else {
            // Narrow layout: Column with Flexible widgets
            return Column(
              children: [
                // ACTIVITY #1: Row with three smaller stats
                Row(
                  // ACTIVITY #1: Row
                  mainAxisAlignment: MainAxisAlignment
                      .spaceEvenly, // ACTIVITY #1: Equal spacing
                  children: [
                    Flexible(
                        child: _buildMainStatCard(
                            '${growthStats['totalSessions']}',
                            'Sessions',
                            Icons.school)), // ACTIVITY #8: Flexible
                    const SizedBox(width: 8),
                    Flexible(
                        child: _buildMainStatCard(
                            '${growthStats['averageRating']}⭐',
                            'Rating',
                            Icons.star)), // ACTIVITY #8: Flexible
                    const SizedBox(width: 8),
                    Flexible(
                        child: _buildMainStatCard(
                            '${growthStats['currentStreak']}',
                            'Streak',
                            Icons
                                .local_fire_department)), // ACTIVITY #8: Flexible
                  ],
                ),
              ],
            );
          }
        },
      ),
    );
  }

  Widget _buildMainStatCard(String value, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accentGreen, size: 32),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: primaryGreen,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: darkGreen.withValues(alpha: 0.8),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ACTIVITY #10: Both Row and Column in same widget tree for profile details
  Widget _buildProfileDetails() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        // ACTIVITY #10: Column
        children: [
          // Contact information row
          Row(
            // ACTIVITY #10: Row
            children: [
              Expanded(
                  child: _buildDetailCard(Icons.email, 'Email', userEmail)),
              const SizedBox(width: 12),
              Expanded(
                  child: _buildDetailCard(Icons.phone, 'Phone', userPhone)),
            ],
          ),
          const SizedBox(height: 12),

          // Additional stats grid
          Column(
            // ACTIVITY #10: Column
            children: [
              Row(
                // ACTIVITY #10: Row
                children: [
                  Expanded(
                      child: _buildStatCard(
                          '${growthStats['completedSessions']}',
                          'Completed',
                          Icons.check_circle)),
                  const SizedBox(width: 8),
                  Expanded(
                      child: _buildStatCard(
                          '${growthStats['upcomingSessions']}',
                          'Upcoming',
                          Icons.schedule)),
                  const SizedBox(width: 8),
                  Expanded(
                      child: _buildStatCard('${growthStats['favoriteTutors']}',
                          'Favorites', Icons.favorite)),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                // ACTIVITY #10: Row
                children: [
                  Expanded(
                      child: _buildStatCard(
                          '${growthStats['totalHoursLearned']}h',
                          'Hours',
                          Icons.access_time)),
                  const SizedBox(width: 8),
                  Expanded(
                      child: _buildStatCard('${growthStats['achievements']}',
                          'Badges', Icons.military_tech)),
                  const SizedBox(width: 8),
                  Expanded(
                      child:
                          _buildStatCard('🌱', 'Growing', Icons.trending_up)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDetailCard(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: lightGreen.withValues(alpha: 0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: primaryGreen, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: primaryGreen.withValues(alpha: 0.8),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 14,
                    color: darkGreen,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String value, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cardGreen,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: lightGreen, width: 2),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accentGreen, size: 20),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: primaryGreen,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              color: darkGreen.withValues(alpha: 0.8),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildProfileActions() {
    return Container(
      margin: const EdgeInsets.all(16),
      child: Column(
        children: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _showEditDialog,
              icon: const Icon(Icons.edit),
              label: const Text('Cultivate Profile'),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _showSettings,
                  icon: const Icon(Icons.settings),
                  label: const Text('Settings'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: primaryGreen,
                    side: const BorderSide(color: primaryGreen, width: 2),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _showAchievements,
                  icon: const Icon(Icons.military_tech),
                  label: const Text('Achievements'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: accentGreen,
                    side: const BorderSide(color: accentGreen, width: 2),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showEditDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.edit, color: primaryGreen),
            SizedBox(width: 8),
            Text('Cultivate Profile', style: TextStyle(color: darkGreen)),
          ],
        ),
        content: const Text(
          'Profile editing is growing! Soon you\'ll be able to update your information and watch your growth flourish.',
          style: TextStyle(color: darkGreen),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Later', style: TextStyle(color: primaryGreen)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryGreen,
              foregroundColor: Colors.white,
            ),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }

  void _showSettings() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.settings, color: primaryGreen),
            SizedBox(width: 8),
            Text('Growth Settings', style: TextStyle(color: darkGreen)),
          ],
        ),
        content: const Text(
          'Settings panel is blooming! Customize your TutorGrow experience and nurture your learning preferences.',
          style: TextStyle(color: darkGreen),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: primaryGreen)),
          ),
        ],
      ),
    );
  }

  void _showAchievements() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.military_tech, color: accentGreen),
            SizedBox(width: 8),
            Text('Growth Achievements', style: TextStyle(color: darkGreen)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Your learning achievements are flourishing! 🌟',
              style: TextStyle(color: darkGreen),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              children: [
                _buildAchievementBadge('🌱', 'First Session'),
                _buildAchievementBadge('📚', 'Bookworm'),
                _buildAchievementBadge('⭐', 'Top Rated'),
                _buildAchievementBadge('🔥', '7-Day Streak'),
                _buildAchievementBadge('🎯', 'Goal Achiever'),
                _buildAchievementBadge('🌳', 'Knowledge Tree'),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: primaryGreen)),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievementBadge(String emoji, String title) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: lightGreen.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentGreen, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 4),
          Text(
            title,
            style: const TextStyle(
              fontSize: 10,
              color: primaryGreen,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: primaryGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
