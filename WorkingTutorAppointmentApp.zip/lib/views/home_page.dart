import 'package:flutter/material.dart';
import '../models/tutor.dart';
import '../services/tutor_service.dart';
import '../services/booking_service.dart';

class HomePage extends StatefulWidget {
  final Function(int)? onNavigationChanged;

  const HomePage({
    super.key,
    this.onNavigationChanged,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  List<Tutor> tutors = [];
  List<Tutor> filteredTutors = [];
  String _selectedSubject = 'All';
  late AnimationController _animationController;
  bool _isLoading = false;

  final List<String> _subjects = [
    'All',
    'Math',
    'Physics',
    'Chemistry',
    'Biology',
    'English'
  ];

  // Green Color Palette - TutorGrow theme
  static const Color primaryGreen = Color(0xFF2E7D32);
  static const Color lightGreen = Color(0xFFA5D6A7);
  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color accentGreen = Color(0xFF66BB6A);
  static const Color backgroundGreen = Color(0xFFF1F8E9);
  static const Color cardGreen = Color(0xFFE8F5E8);

  // Responsive breakpoints
  bool get isMobile => MediaQuery.of(context).size.width < 768;
  bool get isTablet =>
      MediaQuery.of(context).size.width >= 768 &&
      MediaQuery.of(context).size.width < 1200;
  bool get isDesktop => MediaQuery.of(context).size.width >= 1200;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _loadTutors();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadTutors() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 800));
    tutors = TutorService.getTutors();
    filteredTutors = List.from(tutors);
    setState(() => _isLoading = false);
    _animationController.forward();
  }

  void _filterTutors(String subject) {
    List<Tutor> results = List.from(tutors);

    if (subject != 'All') {
      results =
          results.where((tutor) => tutor.subject.contains(subject)).toList();
    }

    setState(() {
      filteredTutors = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundGreen,
      appBar: _buildTutorGrowAppBar(),
      drawer: _buildTutorGrowSidebar(), // LEFT sidebar for all pages
      body: _buildMobileLayout(),
    );
  }

  PreferredSizeWidget _buildTutorGrowAppBar() {
    return AppBar(
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              color: lightGreen,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.eco, color: primaryGreen, size: 24),
          ),
          const SizedBox(width: 12),
          const Text('TutorGrow',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
      backgroundColor: primaryGreen,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8),
          child: IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.search, color: Colors.white),
            ),
            onPressed: () => _showSnackBar('Search feature growing soon! 🌱'),
          ),
        ),
      ],
    );
  }

  // ACTIVITY #3: Container with padding, margin, and background color around Text
  Widget _buildTutorGrowSidebar() {
    return Drawer(
      backgroundColor: cardGreen,
      child: Column(
        children: [
          Container(
            height: 220,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [primaryGreen, accentGreen],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: lightGreen,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: darkGreen.withValues(alpha: 0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.school,
                        size: 40,
                        color: primaryGreen,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'TutorGrow',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const Text(
                      'Grow Your Knowledge 🌱',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: cardGreen,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  // Page Navigation
                  _buildTutorGrowSection('Navigation'),
                  _buildTutorGrowSidebarItem(
                      Icons.home,
                      'Grow',
                      'Find tutors to grow',
                      () => widget.onNavigationChanged?.call(0)),
                  _buildTutorGrowSidebarItem(
                      Icons.calendar_today,
                      'Sessions',
                      'Your learning sessions',
                      () => widget.onNavigationChanged?.call(1)),
                  _buildTutorGrowSidebarItem(
                      Icons.chat_bubble,
                      'Chat',
                      'Message your tutors',
                      () => widget.onNavigationChanged?.call(2)),
                  _buildTutorGrowSidebarItem(
                      Icons.person,
                      'Profile',
                      'Your growth profile',
                      () => widget.onNavigationChanged?.call(3)),

                  const SizedBox(height: 24),
                  _buildTutorGrowSection('Learning Hub'),
                  _buildTutorGrowSidebarItem(
                      Icons.book_outlined,
                      'Study Materials',
                      'Access learning resources',
                      () => _showSnackBar('Study materials growing! 🌱')),
                  _buildTutorGrowSidebarItem(
                      Icons.quiz,
                      'Practice Tests',
                      'Take practice quizzes',
                      () => _showSnackBar('Practice tests blooming! 🌸')),
                  _buildTutorGrowSidebarItem(
                      Icons.trending_up,
                      'Progress Tracker',
                      'Monitor your growth',
                      () => _showSnackBar('Track your learning growth! 📈')),

                  const SizedBox(height: 24),
                  _buildTutorGrowSection('Platform Settings'),
                  _buildTutorGrowSidebarItem(
                      Icons.notifications_outlined,
                      'Notifications',
                      'Manage your alerts',
                      () => _showSnackBar('Notification settings! 🔔')),
                  _buildTutorGrowSidebarItem(
                      Icons.help_outline,
                      'Help & Support',
                      'Get assistance',
                      _showTutorGrowSupportDialog),
                  _buildTutorGrowSidebarItem(
                      Icons.info_outline,
                      'About TutorGrow',
                      'Learn about our platform',
                      _showTutorGrowAboutDialog),
                  _buildTutorGrowSidebarItem(
                      Icons.eco,
                      'Growth Initiative',
                      'Our learning philosophy',
                      () => _showSnackBar('Growing knowledge naturally! 🌍')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTutorGrowSection(String title) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.bold,
          color: darkGreen,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  // ACTIVITY #3: Container with padding, margin, and background color around Text
  Widget _buildTutorGrowSidebarItem(
      IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 4), // ACTIVITY #3: Margin
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(16), // ACTIVITY #3: Padding
            decoration: BoxDecoration(
              // ACTIVITY #3: Background color
              color: Colors.white.withValues(alpha: 0.7),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: accentGreen.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: lightGreen.withValues(alpha: 0.3),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    color: primaryGreen,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ACTIVITY #3: Text widget with container styling
                      Text(
                        title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: darkGreen,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 12,
                          color: primaryGreen.withValues(alpha: 0.8),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: accentGreen.withValues(alpha: 0.6),
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMobileLayout() {
    return Container(
      color: backgroundGreen,
      child: Column(
        children: [
          _buildTutorGrowHeroSection(),
          _buildCircularSubjectNavigation(), // ACTIVITY #6: Navigation bar with icons
          Expanded(child: _buildTutorGrowTutorGrid()),
          _buildBottomStatsBar(), // ACTIVITY #1: Three Text widgets in Row
        ],
      ),
    );
  }

  // ACTIVITY #7: Stack layout with background and floating button overlay
  Widget _buildTutorGrowHeroSection() {
    return Container(
      margin: EdgeInsets.all(isMobile ? 16 : 24),
      height: isMobile ? 160 : 200,
      child: Stack(
        // ACTIVITY #7: Stack layout
        children: [
          // ACTIVITY #7: Background with gradient
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  accentGreen.withValues(alpha: 0.9),
                  primaryGreen.withValues(alpha: 0.8),
                  darkGreen.withValues(alpha: 0.9),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: accentGreen.withValues(alpha: 0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
          ),

          // Content overlay
          Positioned.fill(
            child: Container(
              padding: EdgeInsets.all(isMobile ? 20 : 28),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.eco, color: Colors.white, size: 28),
                      const SizedBox(width: 8),
                      Text(
                        'Grow Your Knowledge',
                        style: TextStyle(
                          fontSize: isMobile ? 22 : 26,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Connect with expert tutors and cultivate your learning journey',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white.withValues(alpha: 0.9),
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ),

          // ACTIVITY #7: Floating button overlay
          Positioned(
            bottom: -8,
            right: 20,
            child: Container(
              decoration: BoxDecoration(
                color: lightGreen,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: darkGreen.withValues(alpha: 0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: FloatingActionButton(
                onPressed: () => _showSnackBar('Welcome to TutorGrow! 🌱'),
                backgroundColor: lightGreen,
                foregroundColor: primaryGreen,
                elevation: 0,
                child: const Icon(Icons.nature, size: 28),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ACTIVITY #6: Navigation bar using Row with icons spaced evenly
  Widget _buildCircularSubjectNavigation() {
    return Container(
      height: 100,
      margin:
          EdgeInsets.symmetric(horizontal: isMobile ? 16 : 24, vertical: 12),
      child: Row(
        // ACTIVITY #6: Row with icons
        mainAxisAlignment:
            MainAxisAlignment.spaceEvenly, // ACTIVITY #6: Even spacing
        children: _subjects.map((subject) {
          final isSelected = _selectedSubject == subject;
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() => _selectedSubject = subject);
                _filterTutors(subject);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  color: isSelected ? primaryGreen : cardGreen,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: (isSelected ? primaryGreen : accentGreen)
                          .withValues(alpha: 0.2),
                      blurRadius: isSelected ? 12.0 : 6.0,
                      offset: Offset(0, isSelected ? 6.0 : 3.0),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      // ACTIVITY #6: Icons
                      _getSubjectIcon(subject),
                      color: isSelected ? Colors.white : primaryGreen,
                      size: isSelected ? 28 : 24,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      subject,
                      style: TextStyle(
                        fontSize: 10,
                        color: isSelected ? Colors.white : primaryGreen,
                        fontWeight:
                            isSelected ? FontWeight.w700 : FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  IconData _getSubjectIcon(String subject) {
    switch (subject) {
      case 'All':
        return Icons.grid_view;
      case 'Math':
        return Icons.calculate_outlined;
      case 'Physics':
        return Icons.science_outlined;
      case 'Chemistry':
        return Icons.biotech_outlined;
      case 'Biology':
        return Icons.eco;
      case 'English':
        return Icons.menu_book;
      default:
        return Icons.school_outlined;
    }
  }

  Widget _buildTutorGrowTutorGrid() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              color: primaryGreen,
              backgroundColor: lightGreen.withValues(alpha: 0.3),
            ),
            const SizedBox(height: 16),
            const Text(
              'Growing your tutor list... 🌱',
              style: TextStyle(
                color: primaryGreen,
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }

    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return FadeTransition(
          opacity: _animationController,
          child: Container(
            color: backgroundGreen,
            padding: EdgeInsets.all(isMobile ? 16 : 24),
            child: SingleChildScrollView(
              child: _buildTutorGrowCustomGrid(),
            ),
          ),
        );
      },
    );
  }

  // ACTIVITY #10: Both Row and Column in same widget tree to form grid-like layout
  Widget _buildTutorGrowCustomGrid() {
    final columns = isMobile ? 1 : (isTablet ? 2 : 3);
    final rows = (filteredTutors.length / columns).ceil();

    return Column(
      // ACTIVITY #10: Column
      children: List.generate(rows, (rowIndex) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 24),
          child: Row(
            // ACTIVITY #10: Row
            crossAxisAlignment: CrossAxisAlignment.start,
            children: List.generate(columns, (colIndex) {
              final tutorIndex = rowIndex * columns + colIndex;
              if (tutorIndex >= filteredTutors.length) {
                return Expanded(child: Container());
              }
              // ACTIVITY #5: Expanded containers sharing screen width
              return Expanded(
                child: Padding(
                  padding: EdgeInsets.only(
                    right: colIndex < columns - 1 ? 16 : 0,
                    left: colIndex > 0 ? 16 : 0,
                  ),
                  child: _buildTutorGrowTutorCard(filteredTutors[tutorIndex]),
                ),
              );
            }),
          ),
        );
      }),
    );
  }

  // ACTIVITY #4: Profile card layout with Row (picture + name) and Column (details) - TutorGrow theme
  Widget _buildTutorGrowTutorCard(Tutor tutor) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.2),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              height: 6,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [lightGreen, accentGreen, primaryGreen],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ACTIVITY 4: Row for profile picture + name (circular design)
                  Row(
                    // ACTIVITY #4: Row layout
                    children: [
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: accentGreen.withValues(alpha: 0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(32),
                          child: Image.network(
                            tutor.avatarUrl,
                            width: 64,
                            height: 64,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                              width: 64,
                              height: 64,
                              decoration: BoxDecoration(
                                color: lightGreen.withValues(alpha: 0.3),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.person,
                                size: 32,
                                color: primaryGreen,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          // ACTIVITY #4: Column for details
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              tutor.name,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: darkGreen,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: lightGreen.withValues(alpha: 0.3),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.eco,
                                    size: 14,
                                    color: primaryGreen,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    tutor.subject,
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: primaryGreen,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Rating and availability
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.star, color: Colors.amber, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            tutor.rating.toString(),
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              color: darkGreen,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: tutor.isAvailable
                              ? accentGreen.withValues(alpha: 0.1)
                              : Colors.grey.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.circle,
                              size: 8,
                              color:
                                  tutor.isAvailable ? accentGreen : Colors.grey,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              tutor.isAvailable ? 'Available' : 'Busy',
                              style: TextStyle(
                                fontSize: 11,
                                color: tutor.isAvailable
                                    ? accentGreen
                                    : Colors.grey,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  Text(
                    '\$${tutor.hourlyRate.toInt()}/hour',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: primaryGreen,
                    ),
                  ),

                  const SizedBox(height: 16),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        BookingService.instance.addBooking(tutor);
                        _showSnackBar('🌱 Growing session with ${tutor.name}!');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryGreen,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Start Growing 🌿',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ACTIVITY #1: Three Text widgets in Row with equal spacing
  Widget _buildBottomStatsBar() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        // ACTIVITY #1: Row with three Text widgets
        mainAxisAlignment:
            MainAxisAlignment.spaceEvenly, // ACTIVITY #1: Equal spacing
        children: [
          _buildBottomStatItem('${tutors.length}', 'Growth Tutors', Icons.eco),
          _buildVerticalDivider(),
          _buildBottomStatItem('${tutors.where((t) => t.isAvailable).length}',
              'Available Now', Icons.online_prediction),
          _buildVerticalDivider(),
          _buildBottomStatItem('${BookingService.instance.getBookingsCount()}',
              'Sessions Today', Icons.schedule),
        ],
      ),
    );
  }

  Widget _buildBottomStatItem(String value, String label, IconData icon) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: primaryGreen, size: 24),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: darkGreen,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: primaryGreen.withValues(alpha: 0.8),
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildVerticalDivider() {
    return Container(
      width: 1,
      height: 40,
      color: lightGreen.withValues(alpha: 0.5),
    );
  }

  void _showTutorGrowSupportDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.help, color: primaryGreen),
            SizedBox(width: 8),
            Text('TutorGrow Support', style: TextStyle(color: darkGreen)),
          ],
        ),
        content: const Text(
          'Our support team is here to help you grow! 🌱 We\'re dedicated to cultivating your learning journey.',
          style: TextStyle(color: darkGreen),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: primaryGreen)),
          ),
        ],
      ),
    );
  }

  void _showTutorGrowAboutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardGreen,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.eco, color: primaryGreen),
            SizedBox(width: 8),
            Text('About TutorGrow', style: TextStyle(color: darkGreen)),
          ],
        ),
        content: const Text(
          'TutorGrow helps students cultivate their learning through personalized tutoring. We believe knowledge grows naturally with the right guidance! 🌿',
          style: TextStyle(color: darkGreen),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: primaryGreen)),
          ),
        ],
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: primaryGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
