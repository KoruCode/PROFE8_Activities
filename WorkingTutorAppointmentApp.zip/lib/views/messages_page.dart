import 'package:flutter/material.dart';
import '../models/tutor.dart';
import '../services/tutor_service.dart';

class MessagesPage extends StatefulWidget {
  final Function(int)? onNavigationChanged;

  const MessagesPage({
    super.key,
    this.onNavigationChanged,
  });

  @override
  State<MessagesPage> createState() => _MessagesPageState();
}

class _MessagesPageState extends State<MessagesPage>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  List<Tutor> tutors = [];
  List<ChatHead> chatHeads = [];
  ChatHead? selectedChatHead;
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _messagesScrollController = ScrollController();
  Map<String, List<Message>> conversationHistory = {};

  // TutorGrow Color Palette
  static const Color primaryGreen = Color(0xFF2E7D32);
  static const Color lightGreen = Color(0xFFA5D6A7);
  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color accentGreen = Color(0xFF66BB6A);
  static const Color backgroundGreen = Color(0xFFF1F8E9);
  static const Color cardGreen = Color(0xFFE8F5E8);

  // Responsive breakpoints
  bool get isMobile => MediaQuery.of(context).size.width < 768;
  bool get isTablet =>
      MediaQuery.of(context).size.width >= 768 &&
      MediaQuery.of(context).size.width < 1200;
  bool get isDesktop => MediaQuery.of(context).size.width >= 1200;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _loadTutors();
    _generateSampleConversations();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _messageController.dispose();
    _messagesScrollController.dispose();
    super.dispose();
  }

  void _loadTutors() {
    tutors = TutorService.getTutors();
    chatHeads = tutors
        .map((tutor) => ChatHead(
              id: tutor.id,
              name: tutor.name,
              avatarUrl: tutor.avatarUrl,
              subject: tutor.subject,
              isOnline: tutor.isAvailable,
              lastMessage: _getLastMessagePreview(tutor.id),
              lastMessageTime: DateTime.now()
                  .subtract(Duration(minutes: tutors.indexOf(tutor) * 30 + 15)),
              unreadCount: tutors.indexOf(tutor) % 3 == 0
                  ? tutors.indexOf(tutor) % 4
                  : 0,
            ))
        .toList();
    _animationController.forward();
  }

  void _generateSampleConversations() {
    final sampleMessages = {
      '1': [
        Message(
            text: 'Hello! Ready to grow your knowledge? 🌱',
            isMe: false,
            time: DateTime.now().subtract(const Duration(hours: 2))),
        Message(
            text: 'Yes! I\'m excited to learn with you!',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 1, minutes: 50))),
        Message(
            text: 'Great! What topic would you like to explore today?',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 1, minutes: 45))),
        Message(
            text: 'I need help with calculus integration',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 1, minutes: 40))),
        Message(
            text: 'Perfect! Let\'s cultivate your calculus skills 📚',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 1, minutes: 35))),
        Message(
            text: 'We can start with basic integration rules',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 1, minutes: 30))),
        Message(
            text: 'That sounds great! When can we start?',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 1, minutes: 25))),
        Message(
            text: 'How about we schedule a session for tomorrow at 3 PM?',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 1, minutes: 20))),
      ],
      '2': [
        Message(
            text: 'Hi! I saw you\'re interested in physics tutoring 🔬',
            isMe: false,
            time: DateTime.now().subtract(const Duration(hours: 4))),
        Message(
            text: 'Yes, I\'m struggling with momentum problems',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 3, minutes: 45))),
        Message(
            text:
                'No worries! Physics can be challenging, but we\'ll make it click for you',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 3, minutes: 40))),
        Message(
            text: 'I have some great examples that will help you understand',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 3, minutes: 35))),
        Message(
            text: 'That would be amazing, thank you!',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 3, minutes: 30))),
      ],
      '3': [
        Message(
            text: 'Good morning! Hope you\'re growing well today 🌿',
            isMe: false,
            time: DateTime.now().subtract(const Duration(hours: 6))),
        Message(
            text: 'Good morning! Yes, ready for our chemistry session',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 5, minutes: 55))),
        Message(
            text: 'Excellent! Today we\'ll explore organic chemistry reactions',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 5, minutes: 50))),
        Message(
            text: 'I have all my notes ready!',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 5, minutes: 45))),
        Message(
            text: 'Perfect preparation! That\'s how knowledge grows 🌱',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 5, minutes: 40))),
      ],
      '4': [
        Message(
            text: 'Hello! Ready to explore biology together? 🧬',
            isMe: false,
            time: DateTime.now().subtract(const Duration(hours: 8))),
        Message(
            text: 'Absolutely! I love how you explain complex topics',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 7, minutes: 45))),
        Message(
            text: 'Thank you! Making learning grow naturally is my passion',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 7, minutes: 40))),
        Message(
            text: 'Can we review cell division today?',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 7, minutes: 35))),
        Message(
            text: 'Of course! Mitosis and meiosis - fascinating processes!',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 7, minutes: 30))),
      ],
      '5': [
        Message(
            text:
                'Hi there! Excited about our English literature discussion 📖',
            isMe: false,
            time: DateTime.now().subtract(const Duration(hours: 10))),
        Message(
            text: 'Yes! I finished reading the chapter you assigned',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 9, minutes: 45))),
        Message(
            text: 'Wonderful! What themes did you notice?',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 9, minutes: 40))),
        Message(
            text:
                'The author uses nature metaphors a lot, very fitting for growth themes',
            isMe: true,
            time:
                DateTime.now().subtract(const Duration(hours: 9, minutes: 35))),
        Message(
            text: 'Brilliant observation! Literature helps our minds grow 🌱',
            isMe: false,
            time:
                DateTime.now().subtract(const Duration(hours: 9, minutes: 30))),
      ],
    };

    conversationHistory = sampleMessages;

    // Update chat heads with conversation data
    for (int i = 0; i < chatHeads.length && i < 5; i++) {
      final chatId = (i + 1).toString();
      if (conversationHistory.containsKey(chatId)) {
        final messages = conversationHistory[chatId]!;
        chatHeads[i] = chatHeads[i].copyWith(
          lastMessage: messages.last.text,
          lastMessageTime: messages.last.time,
        );
      }
    }
  }

  String _getLastMessagePreview(String tutorId) {
    final messages = conversationHistory[tutorId];
    if (messages != null && messages.isNotEmpty) {
      return messages.last.text;
    }
    return 'Ready to start growing knowledge together! 🌱';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundGreen,
      appBar: _buildTutorGrowAppBar(),
      drawer: _buildTutorGrowSidebar(),
      body: isMobile && selectedChatHead != null
          ? _buildChatView()
          : _buildChatLayout(),
    );
  }

  PreferredSizeWidget _buildTutorGrowAppBar() {
    return AppBar(
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              color: lightGreen,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.chat_bubble_outline,
                color: primaryGreen, size: 24),
          ),
          const SizedBox(width: 12),
          const Text('Growth Chat',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
      backgroundColor: primaryGreen,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
      actions: [
        // REMOVED: Video call button as requested
        Container(
          margin: const EdgeInsets.only(right: 8),
          child: IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.search, color: Colors.white),
            ),
            onPressed: () => _showSnackBar('Chat search growing soon! 🔍'),
          ),
        ),
      ],
    );
  }

  // ACTIVITY #3: Container with padding, margin, and background color around Text
  Widget _buildTutorGrowSidebar() {
    return Drawer(
      backgroundColor: cardGreen,
      child: Column(
        children: [
          Container(
            height: 200,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [primaryGreen, accentGreen],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        color: lightGreen,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: darkGreen.withValues(alpha: 0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.forum,
                        size: 35,
                        color: primaryGreen,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Growth Chat',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const Text(
                      'Grow Through Conversation',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: cardGreen,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  // Page Navigation
                  _buildSidebarSection('Navigation'),
                  _buildGreenSidebarItem(
                      Icons.home,
                      'Grow',
                      'Find tutors to grow',
                      () => widget.onNavigationChanged?.call(0)),
                  _buildGreenSidebarItem(
                      Icons.calendar_today,
                      'Sessions',
                      'Your learning sessions',
                      () => widget.onNavigationChanged?.call(1)),
                  _buildGreenSidebarItem(
                      Icons.chat_bubble,
                      'Chat',
                      'Message your tutors',
                      () => widget.onNavigationChanged?.call(2)),
                  _buildGreenSidebarItem(
                      Icons.person,
                      'Profile',
                      'Your growth profile',
                      () => widget.onNavigationChanged?.call(3)),

                  const SizedBox(height: 20),

                  // ACTIVITY #2: Two buttons in Column, centered vertically and horizontally
                  _buildQuickChatActions(),

                  const SizedBox(height: 20),
                  _buildSidebarSection('Chat Garden'),
                  _buildGreenSidebarItem(Icons.mark_chat_read, 'Mark All Read',
                      'Clear notifications', () => _markAllRead()),
                  _buildGreenSidebarItem(
                      Icons.archive,
                      'Archive Chats',
                      'Organize conversations',
                      () => _showSnackBar('Chats archived! 📦')),
                  _buildGreenSidebarItem(
                      Icons.search,
                      'Search Messages',
                      'Find conversations',
                      () => _showSnackBar('Search blooming! 🔍')),

                  const SizedBox(height: 20),
                  _buildSidebarSection('Growth Tools'),
                  _buildGreenSidebarItem(
                      Icons.translate,
                      'Language Helper',
                      'Translation tools',
                      () => _showSnackBar('Languages growing! 🌍')),
                  _buildGreenSidebarItem(
                      Icons.emoji_emotions,
                      'Emoji Garden',
                      'Express yourself',
                      () => _showSnackBar('Emojis flourishing! 😊')),
                  _buildGreenSidebarItem(
                      Icons.settings,
                      'Chat Settings',
                      'Customize experience',
                      () => _showSnackBar('Settings blooming! ⚙️')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ACTIVITY #2: Two buttons in a Column, centered vertically and horizontally
  Widget _buildQuickChatActions() {
    return Container(
      margin: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 8), // ACTIVITY #3: Margin
      padding: const EdgeInsets.all(20), // ACTIVITY #3: Padding
      decoration: BoxDecoration(
        // ACTIVITY #3: Background color
        color: Colors.white.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center, // ACTIVITY #2: Centered vertically
        crossAxisAlignment:
            CrossAxisAlignment.center, // ACTIVITY #2: Centered horizontally
        children: [
          // ACTIVITY #3: Container with padding, margin, background color around Text
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 6), // ACTIVITY #3: Padding
            margin: const EdgeInsets.only(bottom: 16), // ACTIVITY #3: Margin
            decoration: BoxDecoration(
              // ACTIVITY #3: Background color
              color: lightGreen.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.eco, color: primaryGreen, size: 16),
                SizedBox(width: 6),
                Text(
                  'Quick Chat Actions',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: darkGreen,
                  ),
                ),
              ],
            ),
          ),

          // ACTIVITY #2: Two buttons in Column, centered
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.add_comment),
              label: const Text('Start New Chat'),
              onPressed: () {
                Navigator.pop(context);
                widget.onNavigationChanged?.call(0); // Go to tutors page
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12), // Spacing between buttons
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.mark_chat_read),
              label: const Text('Mark All Read'),
              onPressed: () {
                Navigator.pop(context);
                _markAllRead();
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: primaryGreen,
                side: const BorderSide(color: primaryGreen),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebarSection(String title) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      child: Row(
        children: [
          const Icon(Icons.nature, size: 16, color: darkGreen),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: darkGreen,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGreenSidebarItem(
      IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.6),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: lightGreen.withValues(alpha: 0.4),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: primaryGreen, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: darkGreen,
                        ),
                      ),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 11,
                          color: primaryGreen.withValues(alpha: 0.7),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: accentGreen, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildChatLayout() {
    return Container(
      color: backgroundGreen,
      child: Row(
        children: [
          // Chat heads list on the left
          Expanded(
            flex: isMobile ? 1 : 1,
            child: _buildChatHeadsList(),
          ),
          if (!isMobile) ...[
            Container(
              width: 1,
              color: accentGreen.withValues(alpha: 0.2),
            ),
            // Chat view on the right
            Expanded(
              flex: 2,
              child: selectedChatHead == null
                  ? _buildEmptyState()
                  : _buildChatView(),
            ),
          ],
        ],
      ),
    );
  }

  // ACTIVITY #7: Stack with background and floating notification badges
  Widget _buildChatHeadsList() {
    return Container(
      color: cardGreen,
      child: Column(
        children: [
          // Header with search
          Container(
            height: 100,
            child: Stack(
              // ACTIVITY #7: Stack layout
              children: [
                // ACTIVITY #7: Background gradient
                Container(
                  width: double.infinity,
                  height: double.infinity,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [accentGreen, primaryGreen],
                    ),
                  ),
                ),

                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.forum, color: Colors.white, size: 20),
                            SizedBox(width: 8),
                            Text(
                              'Conversations',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Container(
                          height: 36,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: const TextField(
                            decoration: InputDecoration(
                              hintText: 'Search conversations...',
                              hintStyle: TextStyle(
                                  color: Colors.white70, fontSize: 14),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 8),
                              prefixIcon: Icon(Icons.search,
                                  color: Colors.white70, size: 20),
                            ),
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // ACTIVITY #7: Floating notification badge
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: lightGreen,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: darkGreen.withValues(alpha: 0.2),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Text(
                      '${chatHeads.fold<int>(0, (sum, chat) => sum + chat.unreadCount)}',
                      style: const TextStyle(
                        color: primaryGreen,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ACTIVITY #1: Three Text widgets showing chat stats
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.8),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              // ACTIVITY #1: Row with three Text widgets
              mainAxisAlignment:
                  MainAxisAlignment.spaceEvenly, // ACTIVITY #1: Equal spacing
              children: [
                _buildChatStatItem('${chatHeads.length}', 'Total\nChats'),
                _buildVerticalDivider(),
                _buildChatStatItem(
                    '${chatHeads.where((c) => c.unreadCount > 0).length}',
                    'Unread\nChats'),
                _buildVerticalDivider(),
                _buildChatStatItem(
                    '${chatHeads.where((c) => c.isOnline).length}',
                    'Online\nTutors'),
              ],
            ),
          ),

          // Chat heads list
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: chatHeads.length,
              itemBuilder: (context, index) {
                final chatHead = chatHeads[index];
                final isSelected = selectedChatHead?.id == chatHead.id;

                return _buildChatHeadItem(chatHead, isSelected);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatStatItem(String value, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: primaryGreen,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 10,
            color: darkGreen.withValues(alpha: 0.8),
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildVerticalDivider() {
    return Container(
      width: 1,
      height: 30,
      color: lightGreen.withValues(alpha: 0.5),
    );
  }

  // ACTIVITY #4: Profile card layout with Row (avatar + name) and Column (details)
  Widget _buildChatHeadItem(ChatHead chatHead, bool isSelected) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: isSelected
            ? primaryGreen.withValues(alpha: 0.1)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: isSelected ? Border.all(color: primaryGreen, width: 2) : null,
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        onTap: () => _selectChatHead(chatHead),
        leading: Stack(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: accentGreen.withValues(alpha: 0.2),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: Image.network(
                  chatHead.avatarUrl,
                  width: 48,
                  height: 48,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: lightGreen.withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.person,
                      size: 24,
                      color: primaryGreen,
                    ),
                  ),
                ),
              ),
            ),
            // Online indicator
            if (chatHead.isOnline)
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: accentGreen,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: accentGreen.withValues(alpha: 0.5),
                        blurRadius: 4,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
        title: Row(
          // ACTIVITY #4: Row layout
          children: [
            Expanded(
              child: Text(
                chatHead.name,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: isSelected ? primaryGreen : darkGreen,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (chatHead.unreadCount > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: primaryGreen,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${chatHead.unreadCount}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        subtitle: Column(
          // ACTIVITY #4: Column for details
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              chatHead.lastMessage,
              style: TextStyle(
                fontSize: 12,
                color: (isSelected ? primaryGreen : darkGreen)
                    .withValues(alpha: 0.7),
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: lightGreen.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    chatHead.subject,
                    style: const TextStyle(
                      fontSize: 10,
                      color: primaryGreen,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const Spacer(),
                Text(
                  _formatTime(chatHead.lastMessageTime),
                  style: TextStyle(
                    fontSize: 10,
                    color: (isSelected ? primaryGreen : darkGreen)
                        .withValues(alpha: 0.5),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatView() {
    if (selectedChatHead == null) return _buildEmptyState();

    return Container(
      color: backgroundGreen,
      child: Column(
        children: [
          _buildChatHeader(),
          Expanded(child: _buildMessagesList()),
          _buildMessageInput(),
        ],
      ),
    );
  }

  Widget _buildChatHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: lightGreen, width: 1),
        ),
      ),
      child: Row(
        children: [
          if (isMobile)
            IconButton(
              icon: const Icon(Icons.arrow_back, color: primaryGreen),
              onPressed: () => setState(() => selectedChatHead = null),
            ),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: accentGreen.withValues(alpha: 0.2),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.network(
                selectedChatHead!.avatarUrl,
                width: 40,
                height: 40,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: lightGreen.withValues(alpha: 0.3),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.person,
                    size: 20,
                    color: primaryGreen,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  selectedChatHead!.name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: darkGreen,
                  ),
                ),
                Row(
                  children: [
                    if (selectedChatHead!.isOnline) ...[
                      Container(
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                          color: accentGreen,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                    ],
                    Text(
                      selectedChatHead!.isOnline
                          ? 'Growing online'
                          : 'Away nurturing',
                      style: TextStyle(
                        fontSize: 12,
                        color: primaryGreen.withValues(alpha: 0.8),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.2),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.more_vert, color: primaryGreen),
            ),
            onPressed: _showChatOptions,
          ),
        ],
      ),
    );
  }

  Widget _buildMessagesList() {
    final messages = conversationHistory[selectedChatHead!.id] ?? [];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.builder(
        controller: _messagesScrollController,
        padding: const EdgeInsets.symmetric(vertical: 16),
        itemCount: messages.length,
        itemBuilder: (context, index) {
          final message = messages[index];
          return _buildTutorGrowChatBubble(message);
        },
      ),
    );
  }

  // ACTIVITY 9: Chat bubble UI with Container padding, margin, rounded borders (TutorGrow theme)
  Widget _buildTutorGrowChatBubble(Message message) {
    final isMe = message.isMe;

    return Container(
      margin: EdgeInsets.only(
        // ACTIVITY #9: Margin for bubble positioning
        top: 8,
        bottom: 8,
        left: isMe ? 40 : 0,
        right: isMe ? 0 : 40,
      ),
      child: Row(
        mainAxisAlignment:
            isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) ...[
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: accentGreen.withValues(alpha: 0.2),
                    blurRadius: 2,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  selectedChatHead!.avatarUrl,
                  width: 24,
                  height: 24,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: lightGreen.withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child:
                        const Icon(Icons.person, size: 12, color: primaryGreen),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 12), // ACTIVITY #9: Padding
              decoration: BoxDecoration(
                // ACTIVITY #9: Rounded borders and background
                color: isMe ? primaryGreen : Colors.white,
                borderRadius: BorderRadius.only(
                  // ACTIVITY #9: Rounded borders
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(isMe ? 20 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 20),
                ),
                boxShadow: [
                  BoxShadow(
                    color: (isMe ? primaryGreen : accentGreen)
                        .withValues(alpha: 0.2),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.text,
                    style: TextStyle(
                      fontSize: 14,
                      color: isMe ? Colors.white : darkGreen,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _formatTime(message.time),
                    style: TextStyle(
                      fontSize: 10,
                      color: isMe
                          ? Colors.white.withValues(alpha: 0.7)
                          : primaryGreen.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isMe) ...[
            const SizedBox(width: 8),
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: lightGreen.withValues(alpha: 0.3),
                shape: BoxShape.circle,
                border: Border.all(color: primaryGreen, width: 2),
              ),
              child: const Icon(Icons.person, size: 12, color: primaryGreen),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(color: lightGreen, width: 1),
        ),
      ),
      child: SafeArea(
        child: Row(
          children: [
            IconButton(
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: lightGreen.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.attach_file, color: primaryGreen),
              ),
              onPressed: _showAttachmentOptions,
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: backgroundGreen,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: lightGreen, width: 1),
                ),
                child: TextField(
                  controller: _messageController,
                  decoration: const InputDecoration(
                    hintText: 'Plant your message... 🌱',
                    hintStyle: TextStyle(color: primaryGreen),
                    border: InputBorder.none,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  style: const TextStyle(color: darkGreen),
                  onSubmitted: (text) => _sendMessage(),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [accentGreen, primaryGreen],
                ),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.send, color: Colors.white),
                onPressed: _sendMessage,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: lightGreen.withValues(alpha: 0.2),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.chat_bubble_outline,
              size: 60,
              color: accentGreen,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Select a Conversation',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: darkGreen,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Choose a tutor to start growing your knowledge together!',
            style: TextStyle(
              fontSize: 16,
              color: primaryGreen.withValues(alpha: 0.8),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _selectChatHead(ChatHead chatHead) {
    setState(() {
      selectedChatHead = chatHead;
      // Mark as read
      chatHeads = chatHeads
          .map((head) =>
              head.id == chatHead.id ? head.copyWith(unreadCount: 0) : head)
          .toList();
    });
  }

  void _sendMessage() {
    if (_messageController.text.trim().isEmpty || selectedChatHead == null)
      return;

    final message = Message(
      text: _messageController.text.trim(),
      isMe: true,
      time: DateTime.now(),
    );

    final chatId = selectedChatHead!.id;
    conversationHistory[chatId] = [
      ...(conversationHistory[chatId] ?? []),
      message
    ];

    // Update chat head with new message
    final updatedChatHeads = chatHeads
        .map((head) => head.id == chatId
            ? head.copyWith(
                lastMessage: message.text,
                lastMessageTime: message.time,
              )
            : head)
        .toList();

    setState(() {
      chatHeads = updatedChatHeads;
      _messageController.clear();
    });

    // Auto-scroll to bottom
    Future.delayed(const Duration(milliseconds: 100), () {
      _messagesScrollController.animateTo(
        _messagesScrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });

    // Simulate tutor reply
    Future.delayed(const Duration(seconds: 2), () {
      final replies = [
        'That\'s a great question! Let me help you grow 🌱',
        'I understand! Let\'s cultivate that concept together 📚',
        'Excellent thinking! Your knowledge is blooming 🌸',
        'Perfect! Let\'s nurture that skill 🌿',
        'Great progress! You\'re growing so well! 🌳',
      ];

      final reply = Message(
        text: replies[DateTime.now().millisecond % replies.length],
        isMe: false,
        time: DateTime.now(),
      );

      if (mounted) {
        conversationHistory[chatId] = [
          ...(conversationHistory[chatId] ?? []),
          reply
        ];

        setState(() {
          chatHeads = chatHeads
              .map((head) => head.id == chatId
                  ? head.copyWith(
                      lastMessage: reply.text,
                      lastMessageTime: reply.time,
                    )
                  : head)
              .toList();
        });

        Future.delayed(const Duration(milliseconds: 100), () {
          _messagesScrollController.animateTo(
            _messagesScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        });
      }
    });
  }

  void _markAllRead() {
    setState(() {
      chatHeads =
          chatHeads.map((head) => head.copyWith(unreadCount: 0)).toList();
    });
    _showSnackBar('📖 All messages read! Knowledge absorbed!');
  }

  void _showChatOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: cardGreen,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: lightGreen,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Chat Garden Options',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: darkGreen,
              ),
            ),
            const SizedBox(height: 20),
            _buildChatOption(
                Icons.photo_library, 'Share Resources', 'Send study materials'),
            _buildChatOption(
                Icons.schedule, 'Schedule Session', 'Plan learning time'),
            _buildChatOption(Icons.archive, 'Archive Chat', 'Move to archive'),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildChatOption(IconData icon, String title, String subtitle) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: lightGreen.withValues(alpha: 0.3),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: primaryGreen),
      ),
      title: Text(title, style: const TextStyle(color: darkGreen)),
      subtitle: Text(subtitle,
          style: TextStyle(color: primaryGreen.withValues(alpha: 0.7))),
      onTap: () {
        Navigator.pop(context);
        _showSnackBar('$title - Growing soon! 🌱');
      },
    );
  }

  void _showAttachmentOptions() {
    _showSnackBar('📎 Attachment options growing! Share your files! 🌿');
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inHours < 1) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inDays < 1) {
      return '${difference.inHours}h ago';
    } else {
      return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: primaryGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

// Chat Head model for conversation list
class ChatHead {
  final String id;
  final String name;
  final String avatarUrl;
  final String subject;
  final bool isOnline;
  final String lastMessage;
  final DateTime lastMessageTime;
  final int unreadCount;

  const ChatHead({
    required this.id,
    required this.name,
    required this.avatarUrl,
    required this.subject,
    required this.isOnline,
    required this.lastMessage,
    required this.lastMessageTime,
    required this.unreadCount,
  });

  ChatHead copyWith({
    String? lastMessage,
    DateTime? lastMessageTime,
    int? unreadCount,
  }) {
    return ChatHead(
      id: id,
      name: name,
      avatarUrl: avatarUrl,
      subject: subject,
      isOnline: isOnline,
      lastMessage: lastMessage ?? this.lastMessage,
      lastMessageTime: lastMessageTime ?? this.lastMessageTime,
      unreadCount: unreadCount ?? this.unreadCount,
    );
  }
}

// Message model for chat
class Message {
  final String text;
  final bool isMe;
  final DateTime time;

  const Message({
    required this.text,
    required this.isMe,
    required this.time,
  });
}
