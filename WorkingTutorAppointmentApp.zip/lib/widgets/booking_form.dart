import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import '../models/tutor.dart';
import '../services/tutor_service.dart';
import 'custom_button.dart';

class BookingForm extends StatefulWidget {
  final List<Tutor> tutors;
  final bool isIOS;

  const BookingForm({
    super.key,
    required this.tutors,
    required this.isIOS,
  });

  @override
  State<BookingForm> createState() => _BookingFormState();
}

class _BookingFormState extends State<BookingForm> {
  Tutor? selectedTutor;
  String? selectedTimeSlot;
  DateTime selectedDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Title
          Text(
            'Book a Tutoring Session',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),

          // Tutor Selection
          Text(
            'Select Tutor:',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<Tutor>(
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Choose a tutor',
            ),
            value: selectedTutor,
            items: widget.tutors.map((tutor) {
              return DropdownMenuItem(
                value: tutor,
                child: Text(
                    '${tutor.name} - ${tutor.subject} (\$${tutor.hourlyRate}/hr)'),
              );
            }).toList(),
            onChanged: (tutor) {
              setState(() {
                selectedTutor = tutor;
                selectedTimeSlot = null; // Reset time slot
              });
            },
          ),
          const SizedBox(height: 24),

          // Date Selection
          Text(
            'Select Date:',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 8),
          ListTile(
            title: Text(
                '${selectedDate.month}/${selectedDate.day}/${selectedDate.year}'),
            trailing: const Icon(Icons.calendar_today),
            tileColor: Colors.grey[100],
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: selectedDate,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 30)),
              );
              if (picked != null) {
                setState(() => selectedDate = picked);
              }
            },
          ),
          const SizedBox(height: 24),

          // Time Slots
          Text(
            'Available Time Slots:',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 8),
          if (selectedTutor == null)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('Please select a tutor first'),
            )
          else
            Wrap(
              spacing: 8,
              children: selectedTutor!.availableSlots.map((slot) {
                final isSelected = selectedTimeSlot == slot;
                return FilterChip(
                  label: Text(slot),
                  selected: isSelected,
                  onSelected: (selected) {
                    setState(() {
                      selectedTimeSlot = selected ? slot : null;
                    });
                  },
                  selectedColor: Colors.blue[200],
                  checkmarkColor: Colors.blue[800],
                );
              }).toList(),
            ),
          const SizedBox(height: 32),

          // Booking Summary
          if (selectedTutor != null && selectedTimeSlot != null) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green[50],
                border: Border.all(color: Colors.green[200]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Booking Summary:',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text('Tutor: ${selectedTutor!.name}'),
                  Text('Subject: ${selectedTutor!.subject}'),
                  Text(
                      'Date: ${selectedDate.month}/${selectedDate.day}/${selectedDate.year}'),
                  Text('Time: $selectedTimeSlot'),
                  Text('Rate: \$${selectedTutor!.hourlyRate}/hour'),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Book Button
          ElevatedButton(
            onPressed: selectedTutor != null && selectedTimeSlot != null
                ? () {
                    // Simple success dialog instead of SnackBar
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Success!'),
                        content: Text(
                            'Your session with ${selectedTutor!.name} has been booked for ${selectedDate.month}/${selectedDate.day} at $selectedTimeSlot'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              // Reset form
                              setState(() {
                                selectedTutor = null;
                                selectedTimeSlot = null;
                                selectedDate = DateTime.now();
                              });
                            },
                            child: const Text('OK'),
                          ),
                        ],
                      ),
                    );
                  }
                : null,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              selectedTutor != null && selectedTimeSlot != null
                  ? 'Book Session (\$${selectedTutor!.hourlyRate})'
                  : 'Complete Selection to Book',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
