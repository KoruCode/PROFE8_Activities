import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import '../models/tutor.dart';

/// Enhanced TutorCard with complete green theming and real profile photos
class TutorCard extends StatelessWidget {
  final Tutor tutor;
  final bool isIOS;
  final VoidCallback? onBookPressed;

  const TutorCard({
    super.key,
    required this.tutor,
    required this.isIOS,
    this.onBookPressed,
  });

  /// Dynamic height creates staggered grid effect
  double get _cardHeight {
    final nameLength = tutor.name.length;
    final baseHeight = 280.0;

    // Vary height based on content for staggered effect
    if (nameLength > 20) return baseHeight + 40; // Taller for long names
    if (nameLength > 15) return baseHeight + 20; // Medium height
    if (tutor.rating > 4.8)
      return baseHeight + 30; // Taller for high-rated tutors
    return baseHeight; // Standard height
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Container(
      height: _cardHeight,
      margin: EdgeInsets.only(bottom: isMobile ? 8 : 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.15),
            blurRadius: isMobile ? 8 : 12,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color:
              const Color(0xFF4CAF50).withValues(alpha: 0.2), // 🌿 Green border
          width: 1,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(isMobile ? 12 : 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Avatar with real photo
            _buildAvatarSection(isMobile),
            SizedBox(height: isMobile ? 12 : 16),

            // Tutor information
            _buildTutorInfo(isMobile),

            const Spacer(), // Pushes button to bottom

            // Green-themed book button
            _buildBookButton(isMobile),
          ],
        ),
      ),
    );
  }

  Widget _buildAvatarSection(bool isMobile) {
    return Center(
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF4CAF50)
                      .withValues(alpha: 0.2), // 🌿 Green shadow
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipOval(
              child: Container(
                width: isMobile ? 60 : 70,
                height: isMobile ? 60 : 70,
                decoration: BoxDecoration(
                  color: const Color(0xFF4CAF50)
                      .withValues(alpha: 0.1), // 🌿 Green background
                  shape: BoxShape.circle,
                ),
                child: Image.network(
                  tutor.avatarUrl,
                  width: isMobile ? 60 : 70,
                  height: isMobile ? 60 : 70,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return Center(
                      child: isIOS
                          ? const CupertinoActivityIndicator(
                              color: Color(0xFF2E7D32), // 🌿 Green loading
                            )
                          : const CircularProgressIndicator(
                              color: Color(0xFF2E7D32), // 🌿 Green loading
                              strokeWidth: 2,
                            ),
                    );
                  },
                  errorBuilder: (context, error, stackTrace) {
                    // Fallback to initials if image fails to load
                    return Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF4CAF50)
                            .withValues(alpha: 0.1), // 🌿 Green fallback
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          tutor.name.isNotEmpty
                              ? tutor.name
                                  .split(' ')
                                  .map((n) => n[0])
                                  .take(2)
                                  .join()
                                  .toUpperCase()
                              : '?',
                          style: TextStyle(
                            fontSize: isMobile ? 16 : 18,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF2E7D32), // 🌿 Green text
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
          // Online availability indicator
          if (tutor.isAvailable)
            Positioned(
              bottom: 2,
              right: 2,
              child: Container(
                width: isMobile ? 14 : 16,
                height: isMobile ? 14 : 16,
                decoration: BoxDecoration(
                  color: const Color(0xFF4CAF50), // 🌿 Green online indicator
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTutorInfo(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Tutor name
        Text(
          tutor.name,
          style: TextStyle(
            fontSize: isMobile ? 16 : 18,
            fontWeight: FontWeight.bold,
            color: const Color(0xFF1B5E20), // 🌿 Dark green text
          ),
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        SizedBox(height: isMobile ? 4 : 6),

        // Subject badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xFFF1F8E9), // 🌿 Light green background
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: const Color(0xFF4CAF50)
                    .withValues(alpha: 0.3) // 🌿 Green border
                ),
          ),
          child: Text(
            tutor.subject,
            style: TextStyle(
              fontSize: isMobile ? 11 : 12,
              color: const Color(0xFF2E7D32), // 🌿 Dark green text
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        SizedBox(height: isMobile ? 8 : 10),

        // Rating stars
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ...List.generate(
                5,
                (index) => Icon(
                      index < tutor.rating.floor()
                          ? (isIOS ? CupertinoIcons.star_fill : Icons.star)
                          : (isIOS ? CupertinoIcons.star : Icons.star_border),
                      color: const Color(0xFFFFC107), // Golden stars
                      size: isMobile ? 14 : 16,
                    )),
            const SizedBox(width: 6),
            Text(
              '${tutor.rating}',
              style: TextStyle(
                fontSize: isMobile ? 12 : 13,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        SizedBox(height: isMobile ? 6 : 8),

        // Hourly rate
        Text(
          '\$${tutor.hourlyRate.toInt()}/hour',
          style: TextStyle(
            fontSize: isMobile ? 16 : 18,
            fontWeight: FontWeight.bold,
            color: const Color(0xFF4CAF50), // 🌿 Green price
          ),
        ),
      ],
    );
  }

  Widget _buildBookButton(bool isMobile) {
    if (isIOS) {
      return Container(
        width: double.infinity,
        height: isMobile ? 36 : 40,
        decoration: BoxDecoration(
          color: const Color(0xFF4CAF50), // 🌿 Green background
          borderRadius: BorderRadius.circular(isMobile ? 8 : 12),
        ),
        child: CupertinoButton(
          onPressed: onBookPressed,
          padding: EdgeInsets.zero,
          borderRadius: BorderRadius.circular(isMobile ? 8 : 12),
          child: Text(
            'Book Session',
            style: TextStyle(
              fontSize: isMobile ? 12 : 14,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
        ),
      );
    }

    return SizedBox(
      width: double.infinity,
      height: isMobile ? 36 : 40,
      child: ElevatedButton(
        onPressed: onBookPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF4CAF50), // 🌿 Green button
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(isMobile ? 8 : 12),
          ),
          elevation: 2,
        ),
        child: Text(
          'Book Session',
          style: TextStyle(
            fontSize: isMobile ? 12 : 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
