import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

/// Custom button widget with consistent green theming across platforms
class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isIOS;
  final double? width;
  final Color? backgroundColor;
  final Color? textColor;
  final double? fontSize;
  final EdgeInsets? padding;
  final bool isOutlined;

  const CustomButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isIOS = false,
    this.width,
    this.backgroundColor,
    this.textColor,
    this.fontSize,
    this.padding,
    this.isOutlined = false,
  });

  @override
  Widget build(BuildContext context) {
    final defaultBackgroundColor =
        backgroundColor ?? const Color(0xFF4CAF50); // 🌿 Green theme
    final defaultTextColor = textColor ?? Colors.white;
    final buttonWidth = width;

    if (isIOS) {
      return SizedBox(
        width: buttonWidth,
        child: isOutlined
            ? CupertinoButton(
                onPressed: onPressed,
                padding: padding ??
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Container(
                  padding: padding ??
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    border: Border.all(color: defaultBackgroundColor, width: 2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    text,
                    style: TextStyle(
                      color: defaultBackgroundColor,
                      fontSize: fontSize ?? 16,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              )
            : Container(
                width: buttonWidth,
                decoration: BoxDecoration(
                  color: defaultBackgroundColor, // 🌿 Green background
                  borderRadius: BorderRadius.circular(12),
                ),
                child: CupertinoButton(
                  onPressed: onPressed,
                  padding: padding ?? EdgeInsets.zero,
                  borderRadius: BorderRadius.circular(12),
                  child: Text(
                    text,
                    style: TextStyle(
                      color: defaultTextColor,
                      fontSize: fontSize ?? 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
      );
    }

    return SizedBox(
      width: buttonWidth,
      child: isOutlined
          ? OutlinedButton(
              onPressed: onPressed,
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: defaultBackgroundColor, width: 2),
                padding: padding ??
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                text,
                style: TextStyle(
                  color: defaultBackgroundColor,
                  fontSize: fontSize ?? 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          : ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: defaultBackgroundColor,
                foregroundColor: defaultTextColor,
                padding: padding ??
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
              ),
              child: Text(
                text,
                style: TextStyle(
                  fontSize: fontSize ?? 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
    );
  }
}
